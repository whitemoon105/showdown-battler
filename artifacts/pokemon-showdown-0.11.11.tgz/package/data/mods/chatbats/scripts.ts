export const Scripts: ModdedBattleScriptsData = {
	gen: 9,

	init() {
		this.modData('Learnsets', 'lurantis').learnset.icehammer = ['9L1'];

		this.modData('Learnsets', 'ironcrown').learnset.kingsshield = ['9L1'];
		this.modData('Learnsets', 'ironcrown').learnset.bodypress = ['9L1'];

		this.modData('Learnsets', 'carbink').learnset.moonlight = ['9L1'];
		this.modData('Learnsets', 'carbink').learnset.voltswitch = ['9L1'];
		this.modData('Learnsets', 'carbink').learnset.spikes = ['9L1'];

		this.modData('Learnsets', 'moltres').learnset.woodhammer = ['9L1'];
		this.modData('Learnsets', 'moltres').learnset.wavecrash = ['9L1'];
		this.modData('Learnsets', 'moltres').learnset.defog = ['9L1'];

		this.modData('Learnsets', 'kommoo').learnset.aurasphere = ['9L1'];

		this.modData('Learnsets', 'illumise').learnset.quiverdance = ['9L1'];
		this.modData('Learnsets', 'illumise').learnset.thunderbolt = ['9L1'];
		this.modData('Learnsets', 'illumise').learnset.icebeam = ['9L1'];

		this.modData('Learnsets', 'volbeat').learnset.victorydance = ['9L1'];
		this.modData('Learnsets', 'volbeat').learnset.mightycleave = ['9L1'];
		this.modData('Learnsets', 'volbeat').learnset.earthquake = ['9L1'];

		this.modData('Learnsets', 'abomasnow').learnset.glaciallance = ['9L1'];
		this.modData('Learnsets', 'abomasnow').learnset.appleacid = ['9L1'];
		this.modData('Learnsets', 'abomasnow').learnset.partingshot = ['9L1'];

		this.modData('Learnsets', 'dugtrio').learnset.mightycleave = ['9L1'];
		this.modData('Learnsets', 'dugtrio').learnset.saltcure = ['9L1'];
		this.modData('Learnsets', 'dugtrio').learnset.acrobatics = ['9L1'];

		this.modData('Learnsets', 'altaria').learnset.beakblast = ['9L1'];
		this.modData('Learnsets', 'altaria').learnset.return = ['9L1'];
		this.modData('Learnsets', 'altaria').learnset.explosion = ['9L1'];

		this.modData('Learnsets', 'tyranitar').learnset.stoneaxe = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.ceaselessedge = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.kowtowcleave = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.pursuit = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.switcheroo = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.accelerock = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.dracometeor = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.mysticalpower = ['9L1'];
		this.modData('Learnsets', 'tyranitar').learnset.sandsearstorm = ['9L1'];

		this.modData('Learnsets', 'mimikyu').learnset.spiritshackle = ['9L1'];
		this.modData('Learnsets', 'mimikyu').learnset.uturn = ['9L1'];
		this.modData('Learnsets', 'mimikyu').learnset.obstruct = ['9L1'];

		this.modData('Learnsets', 'mesprit').learnset.agility = ['9L1'];
		this.modData('Learnsets', 'mesprit').learnset.storedpower = ['9L1'];
		this.modData('Learnsets', 'mesprit').learnset.torchsong = ['9L1'];
		this.modData('Learnsets', 'mesprit').learnset.cosmicpower = ['9L1'];
		this.modData('Learnsets', 'mesprit').learnset.aquaring = ['9L1'];
		this.modData('Learnsets', 'mesprit').learnset.freezedry = ['9L1'];

		this.modData('Learnsets', 'electrode').learnset.encore = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.rapidspin = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.explosion = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.finalgambit = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.healingwish = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.lunardance = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.memento = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.mistyexplosion = ['9L1'];
		this.modData('Learnsets', 'electrode').learnset.selfdestruct = ['9L1'];

		this.modData('Learnsets', 'taurospaldeacombat').learnset.extremespeed = ['9L1'];
		this.modData('Learnsets', 'taurospaldeacombat').learnset.uturn = ['9L1'];
		this.modData('Learnsets', 'taurospaldeacombat').learnset.knockoff = ['9L1'];

		this.modData('Learnsets', 'chiyu').learnset.splash = ['9L1'];
		this.modData('Learnsets', 'chiyu').learnset.tripledive = ['9L1'];
		this.modData('Learnsets', 'chiyu').learnset.pyroball = ['9L1'];
		this.modData('Learnsets', 'chiyu').learnset.knockoff = ['9L1'];
		this.modData('Learnsets', 'chiyu').learnset.suckerpunch = ['9L1'];

		this.modData('Learnsets', 'wochien').learnset.partingshot = ['9L1'];
		this.modData('Learnsets', 'wochien').learnset.strengthsap = ['9L1'];
		this.modData('Learnsets', 'wochien').learnset.bouncingbubble = ['9L1'];

		this.modData('Learnsets', 'staraptor').learnset.jumpkick = ['9L1'];
		this.modData('Learnsets', 'staraptor').learnset.flareblitz = ['9L1'];
		this.modData('Learnsets', 'staraptor').learnset.wavecrash = ['9L1'];
		this.modData('Learnsets', 'staraptor').learnset.headsmash = ['9L1'];

		this.modData('Learnsets', 'archaludon').learnset.scald = ['9L1'];
		this.modData('Learnsets', 'archaludon').learnset.hydropump = ['9L1'];

		this.modData('Learnsets', 'malamar').learnset.willowisp = ['9L1'];
		this.modData('Learnsets', 'malamar').learnset.recover = ['9L1'];
		this.modData('Learnsets', 'malamar').learnset.eeriespell = ['9L1'];
		this.modData('Learnsets', 'malamar').learnset.sweetkiss = ['9L1'];
		this.modData('Learnsets', 'malamar').learnset.spiritbreak = ['9L1'];

		this.modData('Learnsets', 'empoleon').learnset.nastyplot = ['9L1'];
		this.modData('Learnsets', 'empoleon').learnset.watershuriken = ['9L1'];
		this.modData('Learnsets', 'empoleon').learnset.tachyoncutter = ['9L1'];
		this.modData('Learnsets', 'empoleon').learnset.secretsword = ['9L1'];

		this.modData('Learnsets', 'regieleki').learnset.blazingtorque = ['9L1'];
		this.modData('Learnsets', 'regieleki').learnset.soak = ['9L1'];

		this.modData('Learnsets', 'lycanrocmidnight').learnset.accelerock = ['9L1'];
		this.modData('Learnsets', 'lycanrocmidnight').learnset.bonerush = ['9L1'];
		this.modData('Learnsets', 'lycanrocmidnight').learnset.stormthrow = ['9L1'];

		this.modData('Learnsets', 'lycanroc').learnset.firelash = ['9L1'];
		this.modData('Learnsets', 'lycanroc').learnset.uturn = ['9L1'];
		this.modData('Learnsets', 'lycanroc').learnset.spikes = ['9L1'];

		this.modData('Learnsets', 'lycanrocdusk').learnset.mountainmaw = ['9L1'];
		this.modData('Learnsets', 'lycanrocdusk').learnset.icefang = ['9L1'];

		this.modData('Learnsets', 'dodrio').learnset.triplearrows = ['9L1'];
		this.modData('Learnsets', 'dodrio').learnset.obstruct = ['9L1'];

		this.modData('Learnsets', 'whiscash').learnset.toxic = ['9L1'];
		this.modData('Learnsets', 'whiscash').learnset.flipturn = ['9L1'];
		this.modData('Learnsets', 'whiscash').learnset.scald = ['9L1'];

		this.modData('Learnsets', 'hippowdon').learnset.saltcure = ['9L1'];

		this.modData('Learnsets', 'cramorant').learnset.beakblast = ['9L1'];

		this.modData('Learnsets', 'grafaiai').learnset.bulkup = ['9L1'];
		this.modData('Learnsets', 'grafaiai').learnset.scavenge = ['9L1'];
		this.modData('Learnsets', 'grafaiai').learnset.drainpunch = ['9L1'];

		this.modData('Learnsets', 'kyurem').learnset.earthquake = ['9L1'];

		this.modData('Learnsets', 'roaringmoon').learnset.firelash = ['9L1'];
		this.modData('Learnsets', 'roaringmoon').learnset.glaiverush = ['9L1'];

		this.modData('Learnsets', 'milotic').learnset.bouncybubble = ['9L1'];
		this.modData('Learnsets', 'milotic').learnset.moonblast = ['9L1'];

		this.modData('Learnsets', 'gogoat').learnset.headsmash = ['9L1'];

		this.modData('Learnsets', 'clodsire').learnset.barbbarrage = ['9L1'];

		this.modData('Learnsets', 'masquerain').learnset.roost = ['9L1'];
		this.modData('Learnsets', 'masquerain').learnset.darkpulse = ['9L1'];

		this.modData('Learnsets', 'kyuremblack').learnset.icehammer = ['9L1'];
		this.modData('Learnsets', 'kyuremblack').learnset.dragonhammer = ['9L1'];
		this.modData('Learnsets', 'kyuremblack').learnset.roost = ['9L1'];
		this.modData('Learnsets', 'kyuremblack').learnset.earthquake = ['9L1'];

		this.modData('Learnsets', 'ironthorns').learnset.ironstrike = ['9L1'];
		this.modData('Learnsets', 'ironthorns').learnset.knockoff = ['9L1'];

		this.modData('Learnsets', 'chienpao').learnset.bulkup = ['9L1'];
		this.modData('Learnsets', 'chienpao').learnset.iciclestorm = ['9L1'];

		this.modData('Learnsets', 'pelipper').learnset.bleakwindstorm = ['9L1'];
		this.modData('Learnsets', 'pelipper').learnset.sandsearstorm = ['9L1'];
		this.modData('Learnsets', 'pelipper').learnset.wildboltstorm = ['9L1'];
		this.modData('Learnsets', 'pelipper').learnset.springtidestorm = ['9L1'];

		this.modData('Learnsets', 'araquanid').learnset.surgingstrikes = ['9L1'];
		this.modData('Learnsets', 'araquanid').learnset.flipturn = ['9L1'];
		this.modData('Learnsets', 'araquanid').learnset.silktrap = ['9L1'];
		this.modData('Learnsets', 'araquanid').learnset.firstimpression = ['9L1'];

		this.modData('Learnsets', 'avalugghisui').learnset.mountainmaw = ['9L1'];

		this.modData('Learnsets', 'swalot').learnset.earthpower = ['9L1'];

		this.modData('Learnsets', 'zapdosgalar').learnset.wildcharge = ['9L1'];

		this.modData('Learnsets', 'phione').learnset.workup = ['9L1'];
		this.modData('Learnsets', 'phione').learnset.tidalsurge = ['9L1'];
		this.modData('Learnsets', 'phione').learnset.geyser = ['9L1'];

		this.modData('Learnsets', 'sudowoodo').learnset.bonsaibounce = ['9L1'];
		this.modData('Learnsets', 'sudowoodo').learnset.synthesis = ['9L1'];

		this.modData('Learnsets', 'dondozo').learnset.hornleech = ['9L1'];
		this.modData('Learnsets', 'dondozo').learnset.fishiousrend = ['9L1'];
		this.modData('Learnsets', 'dondozo').learnset.recover = ['9L1'];
		this.modData('Learnsets', 'dondozo').learnset.flipturn = ['9L1'];

		this.modData('Learnsets', 'golurk').learnset.shatteredseal = ['9L1'];
		this.modData('Learnsets', 'golurk').learnset.trickroom = ['9L1'];
		this.modData('Learnsets', 'golurk').learnset.headlongrush = ['9L1'];

		this.modData('Learnsets', 'meowscarada').learnset.encore = ['9L1'];
		this.modData('Learnsets', 'meowscarada').learnset.spectralthief = ['9L1'];

		this.modData('Learnsets', 'infernape').learnset.alloutassault = ['9L1'];
		this.modData('Learnsets', 'infernape').learnset.mindblown = ['9L1'];
		this.modData('Learnsets', 'infernape').learnset.bitterblade = ['9L1'];

		this.modData('Learnsets', 'salamence').learnset.uturn = ['9L1'];
		this.modData('Learnsets', 'salamence').learnset.dragonascent = ['9L1'];
		this.modData('Learnsets', 'salamence').learnset.bloodmoon = ['9L1'];

		this.modData('Learnsets', 'urshifu').learnset.agility = ['9L1'];
		this.modData('Learnsets', 'urshifu').learnset.aquajet = ['9L1'];

		this.modData('Learnsets', 'urshifurapidstrike').learnset.agility = ['9L1'];
		this.modData('Learnsets', 'urshifurapidstrike').learnset.suckerpunch = ['9L1'];

		this.modData('Learnsets', 'stonjourner').learnset.rockwrecker = ['9L1'];
		this.modData('Learnsets', 'stonjourner').learnset.meteorassault = ['9L1'];
		this.modData('Learnsets', 'stonjourner').learnset.skyattack = ['9L1'];
		this.modData('Learnsets', 'stonjourner').learnset.solarblade = ['9L1'];

		this.modData('Learnsets', 'veluza').learnset.ragefist = ['9L1'];

		this.modData('Learnsets', 'ogerpon').learnset.leafblade = ['9L1'];
		this.modData('Learnsets', 'ogerpon').learnset.crabhammer = ['9L1'];
		this.modData('Learnsets', 'ogerpon').learnset.stoneedge = ['9L1'];

		this.modData('Learnsets', 'dachsbun').learnset.nuzzle = ['9L1'];
		this.modData('Learnsets', 'dachsbun').learnset.spiritbreak = ['9L1'];
		this.modData('Learnsets', 'dachsbun').learnset.morningsun = ['9L1'];

		this.modData('Learnsets', 'magneton').learnset.magnetbomb = ['9L1'];

		this.modData('Learnsets', 'delibird').learnset.iciclestorm = ['9L1'];

		this.modData('Learnsets', 'hitmontop').learnset.bulletseed = ['9L1'];

		this.modData('Learnsets', 'articunogalar').learnset.aeroblast = ['9L1'];
		this.modData('Learnsets', 'articunogalar').learnset.oblivionwing = ['9L1'];
		this.modData('Learnsets', 'articunogalar').learnset.aurasphere = ['9L1'];

		this.modData('Learnsets', 'vaporeon').learnset.voltswitch = ['9L1'];
		this.modData('Learnsets', 'vaporeon').learnset.burnout = ['9L1'];

		this.modData('Learnsets', 'garganacl').learnset.thunderwave = ['9L1'];
		this.modData('Learnsets', 'garganacl').learnset.saltcurse = ['9L1'];
		this.modData('Learnsets', 'garganacl').learnset.purify = ['9L1'];

		this.modData('Learnsets', 'swanna').learnset.bleakwindstorm = ['9L1'];
		this.modData('Learnsets', 'swanna').learnset.steameruption = ['9L1'];
		this.modData('Learnsets', 'swanna').learnset.flyby = ['9L1'];

		this.modData('Learnsets', 'typhlosion').learnset.heatsink = ['9L1'];
		this.modData('Learnsets', 'typhlosion').learnset.steameruption = ['9L1'];
		this.modData('Learnsets', 'typhlosion').learnset.matchagotcha = ['9L1'];
		this.modData('Learnsets', 'typhlosion').learnset.calmmind = ['9L1'];
		this.modData('Learnsets', 'typhlosion').learnset.morningsun = ['9L1'];

		this.modData('Learnsets', 'terapagos').learnset.nastyplot = ['9L1'];

		this.modData('Learnsets', 'tatsugiri').learnset.switcheroo = ['9L1'];
		this.modData('Learnsets', 'tatsugiri').learnset.sashimishuffle = ['9L1'];
		this.modData('Learnsets', 'tatsugiri').learnset.twister = ['9L1'];
		this.modData('Learnsets', 'tatsugiri').learnset.waterspout = ['9L1'];

		this.modData('Learnsets', 'flapple').learnset.earthquake = ['9L1'];
		this.modData('Learnsets', 'flapple').learnset.grabapple = ['9L1'];
		this.modData('Learnsets', 'flapple').learnset.flareblitz = ['9L1'];

		this.modData('Learnsets', 'genesect').learnset.earthquake = ['9L1'];
		this.modData('Learnsets', 'genesect').learnset.sunsteelstrike = ['9L1'];
		this.modData('Learnsets', 'genesect').learnset.behemothblade = ['9L1'];
		this.modData('Learnsets', 'genesect').learnset.makeitrain = ['9L1'];
		this.modData('Learnsets', 'genesect').learnset.tachyoncutter = ['9L1'];

		this.modData('Learnsets', 'honchkrow').learnset.crowverload = ['9L1'];
		this.modData('Learnsets', 'honchkrow').learnset.oblivionwing = ['9L1'];
		this.modData('Learnsets', 'honchkrow').learnset.closecombat = ['9L1'];

		this.modData('Learnsets', 'primeape').learnset.knockoff = ['9L1'];
		this.modData('Learnsets', 'primeape').learnset.ironhead = ['9L1'];

		this.modData('Learnsets', 'rillaboom').learnset.naturesfury = ['9L1'];
		this.modData('Learnsets', 'rillaboom').learnset.landswrath = ['9L1'];

		this.modData('Learnsets', 'mandibuzz').learnset.fling = ['9L1'];
		this.modData('Learnsets', 'mandibuzz').learnset.scavenge = ['9L1'];
		this.modData('Learnsets', 'mandibuzz').learnset.bonemerang = ['9L1'];

		this.modData('Learnsets', 'feraligatr').learnset.firefang = ['9L1'];
		this.modData('Learnsets', 'feraligatr').learnset.thunderfang = ['9L1'];
		this.modData('Learnsets', 'feraligatr').learnset.poisonfang = ['9L1'];

		this.modData('Learnsets', 'salazzle').learnset.magmastorm = ['9L1'];
		this.modData('Learnsets', 'salazzle').learnset.malignantchain = ['9L1'];
		this.modData('Learnsets', 'salazzle').learnset.psychicnoise = ['9L1'];
		this.modData('Learnsets', 'salazzle').learnset.banefulbunker = ['9L1'];

		this.modData('Learnsets', 'kyogre').learnset.hurricane = ['9L1'];
		this.modData('Learnsets', 'kyogre').learnset.tidalsurge = ['9L1'];

		this.modData('Learnsets', 'azelf').learnset.rapidspin = ['9L1'];
		this.modData('Learnsets', 'azelf').learnset.lootbox = ['9L1'];
		this.modData('Learnsets', 'azelf').learnset.acupressure = ['9L1'];

		this.modData('Learnsets', 'decidueye').learnset.sinisterarrows = ['9L1'];

		this.modData('Learnsets', 'ogerpon').learnset.sappyseed = ['9L1'];
		this.modData('Learnsets', 'ogerpon').learnset.thousandwaves = ['9L1'];

		this.modData('Learnsets', 'glimmora').learnset.icebeam = ['9L1'];
		this.modData('Learnsets', 'glimmora').learnset.malignantchain = ['9L1'];

		this.modData('Learnsets', 'wobbuffet').learnset.nightshade = ['9L1'];
		this.modData('Learnsets', 'wobbuffet').learnset.guillotine = ['9L1'];
		this.modData('Learnsets', 'wobbuffet').learnset.shedtail = ['9L1'];

		this.modData('Learnsets', 'raticate').learnset.lastbreakfast = ['9L1'];
	},
};
