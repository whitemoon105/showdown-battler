export const FormatsData: import('../../../sim/dex-species').ModdedSpeciesFormatsDataTable = {
	bulbasaur: {
		tier: "LC",
	},
	ivysaur: {
		tier: "NFE",
	},
	venusaur: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	charmander: {
		tier: "LC",
	},
	charmeleon: {
		tier: "NFE",
	},
	charizard: {
		tier: "NU",
		doublesTier: "DOU",
	},
	squirtle: {
		tier: "LC",
	},
	wartortle: {
		tier: "NU",
		doublesTier: "NFE",
	},
	blastoise: {
		tier: "UU",
		doublesTier: "DUU",
	},
	caterpie: {
		tier: "LC",
	},
	metapod: {
		tier: "NFE",
	},
	butterfree: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	weedle: {
		tier: "LC",
	},
	kakuna: {
		tier: "NFE",
	},
	beedrill: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	pidgey: {
		tier: "LC",
	},
	pidgeotto: {
		tier: "NFE",
	},
	pidgeot: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	rattata: {
		tier: "LC",
	},
	raticate: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	spearow: {
		tier: "LC",
	},
	fearow: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	ekans: {
		tier: "LC",
	},
	arbok: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	pichu: {
		tier: "LC",
	},
	pikachu: {
		tier: "NFE",
	},
	raichu: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	sandshrew: {
		tier: "LC",
	},
	sandslash: {
		tier: "RU",
		doublesTier: "DUU",
	},
	nidoranf: {
		tier: "LC",
	},
	nidorina: {
		tier: "NFE",
	},
	nidoqueen: {
		tier: "UU",
		doublesTier: "DUU",
	},
	nidoranm: {
		tier: "LC",
	},
	nidorino: {
		tier: "NFE",
	},
	nidoking: {
		tier: "UU",
		doublesTier: "DUU",
	},
	cleffa: {
		tier: "LC",
	},
	clefairy: {
		tier: "NFE",
	},
	clefable: {
		tier: "RU",
		doublesTier: "DUU",
	},
	vulpix: {
		tier: "NFE",
	},
	ninetales: {
		tier: "OU",
		doublesTier: "DOU",
	},
	igglybuff: {
		tier: "LC",
	},
	jigglypuff: {
		tier: "NFE",
	},
	wigglytuff: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	zubat: {
		tier: "LC",
	},
	golbat: {
		tier: "NU",
		doublesTier: "NFE",
	},
	crobat: {
		tier: "UU",
		doublesTier: "DUU",
	},
	oddish: {
		tier: "LC",
	},
	gloom: {
		tier: "NFE",
	},
	vileplume: {
		tier: "PU",
		doublesTier: "DUU",
	},
	bellossom: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	paras: {
		tier: "LC",
	},
	parasect: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	venonat: {
		tier: "LC",
	},
	venomoth: {
		tier: "RUBL",
		doublesTier: "DUU",
	},
	diglett: {
		tier: "LC",
	},
	dugtrio: {
		tier: "(OU)",
		doublesTier: "DUU",
	},
	meowth: {
		tier: "LC",
	},
	persian: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	psyduck: {
		tier: "LC",
	},
	golduck: {
		tier: "PU",
		doublesTier: "DUU",
	},
	mankey: {
		tier: "LC",
	},
	primeape: {
		tier: "NU",
		doublesTier: "DUU",
	},
	growlithe: {
		tier: "LC",
	},
	arcanine: {
		tier: "UU",
		doublesTier: "DOU",
	},
	poliwag: {
		tier: "LC",
	},
	poliwhirl: {
		tier: "NFE",
	},
	poliwrath: {
		tier: "RU",
		doublesTier: "DUU",
	},
	politoed: {
		tier: "OU",
		doublesTier: "DOU",
	},
	abra: {
		tier: "LC",
	},
	kadabra: {
		tier: "NU",
		doublesTier: "NFE",
	},
	alakazam: {
		tier: "OU",
		doublesTier: "DUU",
	},
	machop: {
		tier: "LC",
	},
	machoke: {
		tier: "ZUBL",
		doublesTier: "NFE",
	},
	machamp: {
		tier: "UU",
		doublesTier: "DUU",
	},
	bellsprout: {
		tier: "LC",
	},
	weepinbell: {
		tier: "NFE",
	},
	victreebel: {
		tier: "PU",
		doublesTier: "DUU",
	},
	tentacool: {
		tier: "PU",
	},
	tentacruel: {
		tier: "OU",
		doublesTier: "DUU",
	},
	geodude: {
		tier: "LC",
	},
	graveler: {
		tier: "NFE",
	},
	golem: {
		tier: "NU",
		doublesTier: "DUU",
	},
	ponyta: {
		tier: "LC",
	},
	rapidash: {
		tier: "PU",
		doublesTier: "DUU",
	},
	slowpoke: {
		tier: "LC",
	},
	slowbro: {
		tier: "UU",
		doublesTier: "DUU",
	},
	slowking: {
		tier: "RU",
		doublesTier: "DUU",
	},
	magnemite: {
		tier: "LC",
	},
	magneton: {
		tier: "RU",
		doublesTier: "NFE",
	},
	magnezone: {
		tier: "OU",
		doublesTier: "DUU",
	},
	farfetchd: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	doduo: {
		tier: "LC",
	},
	dodrio: {
		tier: "PU",
		doublesTier: "DUU",
	},
	seel: {
		tier: "LC",
	},
	dewgong: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	grimer: {
		tier: "LC",
	},
	muk: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	shellder: {
		tier: "LC",
	},
	cloyster: {
		tier: "Uber",
		doublesTier: "DOU",
	},
	gastly: {
		tier: "LC",
	},
	haunter: {
		tier: "NU",
		doublesTier: "NFE",
	},
	gengar: {
		tier: "OU",
		doublesTier: "DOU",
	},
	onix: {
		tier: "LC",
	},
	steelix: {
		tier: "RU",
		doublesTier: "DUU",
	},
	drowzee: {
		tier: "LC",
	},
	hypno: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	krabby: {
		tier: "LC",
	},
	kingler: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	voltorb: {
		tier: "LC",
	},
	electrode: {
		tier: "NU",
		doublesTier: "DUU",
	},
	exeggcute: {
		tier: "LC",
	},
	exeggutor: {
		tier: "NU",
		doublesTier: "DUU",
	},
	cubone: {
		tier: "LC",
	},
	marowak: {
		tier: "ZUBL",
		doublesTier: "DUU",
	},
	tyrogue: {
		tier: "LC",
	},
	hitmonlee: {
		tier: "RU",
		doublesTier: "DUU",
	},
	hitmonchan: {
		tier: "RU",
		doublesTier: "DUU",
	},
	hitmontop: {
		tier: "UU",
		doublesTier: "DOU",
	},
	lickitung: {
		tier: "LC",
	},
	lickilicky: {
		tier: "NU",
		doublesTier: "DUU",
	},
	koffing: {
		tier: "LC",
	},
	weezing: {
		tier: "NU",
		doublesTier: "DUU",
	},
	rhyhorn: {
		tier: "LC",
	},
	rhydon: {
		tier: "RU",
		doublesTier: "NFE",
	},
	rhyperior: {
		tier: "UU",
		doublesTier: "DUU",
	},
	happiny: {
		tier: "LC",
	},
	chansey: {
		tier: "UUBL",
		doublesTier: "NFE",
	},
	blissey: {
		tier: "OU",
		doublesTier: "DUU",
	},
	tangela: {
		tier: "NU",
		doublesTier: "NFE",
	},
	tangrowth: {
		tier: "RU",
		doublesTier: "DUU",
	},
	kangaskhan: {
		tier: "NU",
		doublesTier: "DUU",
	},
	horsea: {
		tier: "LC",
	},
	seadra: {
		tier: "NFE",
	},
	kingdra: {
		tier: "UU",
		doublesTier: "DOU",
	},
	goldeen: {
		tier: "LC",
	},
	seaking: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	staryu: {
		tier: "LC",
	},
	starmie: {
		tier: "OU",
		doublesTier: "DUU",
	},
	mimejr: {
		tier: "LC",
	},
	mrmime: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	scyther: {
		tier: "RU",
		doublesTier: "NFE",
	},
	scizor: {
		tier: "OU",
		doublesTier: "DOU",
	},
	smoochum: {
		tier: "LC",
	},
	jynx: {
		tier: "NUBL",
		doublesTier: "DUU",
	},
	elekid: {
		tier: "LC",
	},
	electabuzz: {
		tier: "NU",
		doublesTier: "NFE",
	},
	electivire: {
		tier: "RU",
		doublesTier: "DOU",
	},
	magby: {
		tier: "LC",
	},
	magmar: {
		tier: "NFE",
	},
	magmortar: {
		tier: "RU",
		doublesTier: "DUU",
	},
	pinsir: {
		tier: "NU",
		doublesTier: "DUU",
	},
	tauros: {
		tier: "NU",
		doublesTier: "DUU",
	},
	magikarp: {
		tier: "LC",
	},
	gyarados: {
		tier: "OU",
		doublesTier: "DOU",
	},
	lapras: {
		tier: "NU",
		doublesTier: "DUU",
	},
	ditto: {
		tier: "NU",
		doublesTier: "DUU",
	},
	eevee: {
		tier: "LC",
	},
	vaporeon: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	jolteon: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	flareon: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	espeon: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	umbreon: {
		tier: "UU",
		doublesTier: "DUU",
	},
	leafeon: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	glaceon: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	porygon: {
		tier: "LC",
	},
	porygon2: {
		tier: "UU",
		doublesTier: "NFE",
	},
	porygonz: {
		tier: "UU",
		doublesTier: "DUU",
	},
	omanyte: {
		tier: "ZUBL",
		doublesTier: "LC",
	},
	omastar: {
		tier: "RU",
		doublesTier: "DUU",
	},
	kabuto: {
		tier: "LC",
	},
	kabutops: {
		tier: "RU",
		doublesTier: "DUU",
	},
	aerodactyl: {
		tier: "RU",
		doublesTier: "DUU",
	},
	munchlax: {
		tier: "LC",
	},
	snorlax: {
		tier: "UU",
		doublesTier: "DUU",
	},
	articuno: {
		tier: "ZUBL",
		doublesTier: "DUU",
	},
	zapdos: {
		tier: "UU",
		doublesTier: "DOU",
	},
	moltres: {
		tier: "RU",
		doublesTier: "DUU",
	},
	dratini: {
		tier: "LC",
	},
	dragonair: {
		tier: "ZUBL",
		doublesTier: "NFE",
	},
	dragonite: {
		tier: "OU",
		doublesTier: "DOU",
	},
	mewtwo: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	mew: {
		tier: "UU",
		doublesTier: "DUU",
	},
	chikorita: {
		tier: "LC",
	},
	bayleef: {
		tier: "NFE",
	},
	meganium: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	cyndaquil: {
		tier: "LC",
	},
	quilava: {
		tier: "NFE",
	},
	typhlosion: {
		tier: "RU",
		doublesTier: "DUU",
	},
	totodile: {
		tier: "LC",
	},
	croconaw: {
		tier: "NFE",
	},
	feraligatr: {
		tier: "RU",
		doublesTier: "DUU",
	},
	sentret: {
		tier: "LC",
	},
	furret: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	hoothoot: {
		tier: "LC",
	},
	noctowl: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	ledyba: {
		tier: "LC",
	},
	ledian: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	spinarak: {
		tier: "LC",
	},
	ariados: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	chinchou: {
		tier: "LC",
	},
	lanturn: {
		tier: "RU",
		doublesTier: "DUU",
	},
	togepi: {
		tier: "LC",
	},
	togetic: {
		tier: "NFE",
	},
	togekiss: {
		tier: "UU",
		doublesTier: "DOU",
	},
	natu: {
		tier: "PU",
	},
	xatu: {
		tier: "UU",
		doublesTier: "DUU",
	},
	mareep: {
		tier: "LC",
	},
	flaaffy: {
		tier: "NFE",
	},
	ampharos: {
		tier: "NU",
		doublesTier: "DUU",
	},
	azurill: {
		tier: "LC",
	},
	marill: {
		tier: "NFE",
	},
	azumarill: {
		tier: "UU",
		doublesTier: "DUU",
	},
	bonsly: {
		tier: "LC",
	},
	sudowoodo: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	hoppip: {
		tier: "LC",
	},
	skiploom: {
		tier: "NFE",
	},
	jumpluff: {
		tier: "PU",
		doublesTier: "DUU",
	},
	aipom: {
		tier: "LC",
	},
	ambipom: {
		tier: "UU",
		doublesTier: "DUU",
	},
	sunkern: {
		tier: "LC",
	},
	sunflora: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	yanma: {
		tier: "NFE",
	},
	yanmega: {
		tier: "UU",
		doublesTier: "DUU",
	},
	wooper: {
		tier: "LC",
	},
	quagsire: {
		tier: "RU",
		doublesTier: "DUU",
	},
	murkrow: {
		tier: "PU",
	},
	honchkrow: {
		tier: "UU",
		doublesTier: "DUU",
	},
	misdreavus: {
		tier: "NU",
		doublesTier: "NFE",
	},
	mismagius: {
		tier: "UU",
		doublesTier: "DUU",
	},
	unown: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	wynaut: {
		tier: "LC",
	},
	wobbuffet: {
		tier: "UUBL",
		doublesTier: "DUU",
	},
	girafarig: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	pineco: {
		tier: "LC",
	},
	forretress: {
		tier: "OU",
		doublesTier: "DUU",
	},
	dunsparce: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	gligar: {
		tier: "UU",
		doublesTier: "NFE",
	},
	gliscor: {
		tier: "OU",
		doublesTier: "DOU",
	},
	snubbull: {
		tier: "LC",
	},
	granbull: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	qwilfish: {
		tier: "RU",
		doublesTier: "DUU",
	},
	shuckle: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	heracross: {
		tier: "UU",
		doublesTier: "DUU",
	},
	sneasel: {
		tier: "PU",
	},
	weavile: {
		tier: "UU",
		doublesTier: "DOU",
	},
	teddiursa: {
		tier: "LC",
	},
	ursaring: {
		tier: "PU",
		doublesTier: "DUU",
	},
	slugma: {
		tier: "LC",
	},
	magcargo: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	swinub: {
		tier: "LC",
	},
	piloswine: {
		tier: "NU",
		doublesTier: "NFE",
	},
	mamoswine: {
		tier: "OU",
		doublesTier: "DOU",
	},
	corsola: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	remoraid: {
		tier: "LC",
	},
	octillery: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	delibird: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	mantyke: {
		tier: "LC",
	},
	mantine: {
		tier: "PU",
		doublesTier: "DUU",
	},
	skarmory: {
		tier: "OU",
		doublesTier: "DUU",
	},
	houndour: {
		tier: "LC",
	},
	houndoom: {
		tier: "UU",
		doublesTier: "DUU",
	},
	phanpy: {
		tier: "LC",
	},
	donphan: {
		tier: "(OU)",
		doublesTier: "DUU",
	},
	stantler: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	smeargle: {
		tier: "RU",
		doublesTier: "DUU",
	},
	miltank: {
		tier: "NU",
		doublesTier: "DUU",
	},
	raikou: {
		tier: "UU",
		doublesTier: "DUU",
	},
	entei: {
		tier: "RU",
		doublesTier: "DUU",
	},
	suicune: {
		tier: "UU",
		doublesTier: "DUU",
	},
	larvitar: {
		tier: "LC",
	},
	pupitar: {
		tier: "NFE",
	},
	tyranitar: {
		tier: "OU",
		doublesTier: "DOU",
	},
	lugia: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	hooh: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	celebi: {
		tier: "OU",
		doublesTier: "DUU",
	},
	treecko: {
		tier: "LC",
	},
	grovyle: {
		tier: "NFE",
	},
	sceptile: {
		tier: "RU",
		doublesTier: "DUU",
	},
	torchic: {
		tier: "LC",
	},
	combusken: {
		tier: "PUBL",
		doublesTier: "DUU",
	},
	blaziken: {
		tier: "Uber",
		doublesTier: "DOU",
	},
	mudkip: {
		tier: "LC",
	},
	marshtomp: {
		tier: "NFE",
	},
	swampert: {
		tier: "UU",
		doublesTier: "DUU",
	},
	poochyena: {
		tier: "LC",
	},
	mightyena: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	zigzagoon: {
		tier: "LC",
	},
	linoone: {
		tier: "PUBL",
		doublesTier: "DUU",
	},
	wurmple: {
		tier: "LC",
	},
	silcoon: {
		tier: "NFE",
	},
	beautifly: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	cascoon: {
		tier: "NFE",
	},
	dustox: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	lotad: {
		tier: "LC",
	},
	lombre: {
		tier: "NFE",
	},
	ludicolo: {
		tier: "NU",
		doublesTier: "DOU",
	},
	seedot: {
		tier: "LC",
	},
	nuzleaf: {
		tier: "NFE",
	},
	shiftry: {
		tier: "PU",
		doublesTier: "DUU",
	},
	taillow: {
		tier: "LC",
	},
	swellow: {
		tier: "NU",
		doublesTier: "DUU",
	},
	wingull: {
		tier: "LC",
	},
	pelipper: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	ralts: {
		tier: "LC",
	},
	kirlia: {
		tier: "NFE",
	},
	gardevoir: {
		tier: "NU",
		doublesTier: "DUU",
	},
	gallade: {
		tier: "RU",
		doublesTier: "DUU",
	},
	surskit: {
		tier: "LC",
	},
	masquerain: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	shroomish: {
		tier: "LC",
	},
	breloom: {
		tier: "OU",
		doublesTier: "DOU",
	},
	slakoth: {
		tier: "LC",
	},
	vigoroth: {
		tier: "PUBL",
		doublesTier: "NFE",
	},
	slaking: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	nincada: {
		tier: "LC",
	},
	ninjask: {
		tier: "NU",
		doublesTier: "DUU",
	},
	shedinja: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	whismur: {
		tier: "LC",
	},
	loudred: {
		tier: "NFE",
	},
	exploud: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	makuhita: {
		tier: "LC",
	},
	hariyama: {
		tier: "RU",
		doublesTier: "DUU",
	},
	nosepass: {
		tier: "LC",
	},
	probopass: {
		tier: "NU",
		doublesTier: "DUU",
	},
	skitty: {
		tier: "LC",
	},
	delcatty: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	sableye: {
		tier: "UU",
		doublesTier: "DOU",
	},
	mawile: {
		tier: "PU",
		doublesTier: "DUU",
	},
	aron: {
		tier: "LC",
	},
	lairon: {
		tier: "NFE",
	},
	aggron: {
		tier: "RU",
		doublesTier: "DUU",
	},
	meditite: {
		tier: "NFE",
	},
	medicham: {
		tier: "RU",
		doublesTier: "DUU",
	},
	electrike: {
		tier: "LC",
	},
	manectric: {
		tier: "RU",
		doublesTier: "DUU",
	},
	plusle: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	minun: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	volbeat: {
		tier: "PU",
		doublesTier: "DUU",
	},
	illumise: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	budew: {
		tier: "LC",
	},
	roselia: {
		tier: "NU",
		doublesTier: "NFE",
	},
	roserade: {
		tier: "UU",
		doublesTier: "DUU",
	},
	gulpin: {
		tier: "LC",
	},
	swalot: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	carvanha: {
		tier: "LC",
	},
	sharpedo: {
		tier: "UU",
		doublesTier: "DUU",
	},
	wailmer: {
		tier: "LC",
	},
	wailord: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	numel: {
		tier: "LC",
	},
	camerupt: {
		tier: "NU",
		doublesTier: "DUU",
	},
	torkoal: {
		tier: "NU",
		doublesTier: "DUU",
	},
	spoink: {
		tier: "LC",
	},
	grumpig: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	spinda: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	trapinch: {
		tier: "LC",
	},
	vibrava: {
		tier: "NFE",
	},
	flygon: {
		tier: "UU",
		doublesTier: "DUU",
	},
	cacnea: {
		tier: "LC",
	},
	cacturne: {
		tier: "NU",
		doublesTier: "DUU",
	},
	swablu: {
		tier: "LC",
	},
	altaria: {
		tier: "NU",
		doublesTier: "DUU",
	},
	zangoose: {
		tier: "NU",
		doublesTier: "DUU",
	},
	seviper: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	lunatone: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	solrock: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	barboach: {
		tier: "LC",
	},
	whiscash: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	corphish: {
		tier: "LC",
	},
	crawdaunt: {
		tier: "RU",
		doublesTier: "DUU",
	},
	baltoy: {
		tier: "LC",
	},
	claydol: {
		tier: "UU",
		doublesTier: "DUU",
	},
	lileep: {
		tier: "LC",
	},
	cradily: {
		tier: "NU",
		doublesTier: "DUU",
	},
	anorith: {
		tier: "LC",
	},
	armaldo: {
		tier: "NU",
		doublesTier: "DUU",
	},
	feebas: {
		tier: "LC",
	},
	milotic: {
		tier: "UU",
		doublesTier: "DUU",
	},
	castform: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	castformsunny: {
	},
	castformrainy: {
	},
	castformsnowy: {
	},
	kecleon: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	shuppet: {
		tier: "LC",
	},
	banette: {
		tier: "PU",
		doublesTier: "DUU",
	},
	duskull: {
		tier: "LC",
	},
	dusclops: {
		tier: "UU",
		doublesTier: "NFE",
	},
	dusknoir: {
		tier: "RU",
		doublesTier: "DUU",
	},
	tropius: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	chingling: {
		tier: "LC",
	},
	chimecho: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	absol: {
		tier: "RU",
		doublesTier: "DUU",
	},
	snorunt: {
		tier: "LC",
	},
	glalie: {
		tier: "ZUBL",
		doublesTier: "DUU",
	},
	froslass: {
		tier: "UUBL",
		doublesTier: "DUU",
	},
	spheal: {
		tier: "LC",
	},
	sealeo: {
		tier: "NFE",
	},
	walrein: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	clamperl: {
		tier: "LC",
	},
	huntail: {
		tier: "PU",
		doublesTier: "DUU",
	},
	gorebyss: {
		tier: "NU",
		doublesTier: "DUU",
	},
	relicanth: {
		tier: "PU",
		doublesTier: "DUU",
	},
	luvdisc: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	bagon: {
		tier: "LC",
	},
	shelgon: {
		tier: "NFE",
	},
	salamence: {
		tier: "OU",
		doublesTier: "DOU",
	},
	beldum: {
		tier: "LC",
	},
	metang: {
		tier: "NU",
		doublesTier: "NFE",
	},
	metagross: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	regirock: {
		tier: "NU",
		doublesTier: "DUU",
	},
	regice: {
		tier: "NU",
		doublesTier: "DUU",
	},
	registeel: {
		tier: "UU",
		doublesTier: "DUU",
	},
	latias: {
		tier: "OU",
		doublesTier: "DUU",
	},
	latios: {
		tier: "OU",
		doublesTier: "DOU",
	},
	kyogre: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	groudon: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	rayquaza: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	jirachi: {
		tier: "OU",
		doublesTier: "DUber",
	},
	deoxys: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	deoxysattack: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	deoxysdefense: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	deoxysspeed: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	turtwig: {
		tier: "LC",
	},
	grotle: {
		tier: "NFE",
	},
	torterra: {
		tier: "PU",
		doublesTier: "DUU",
	},
	chimchar: {
		tier: "LC",
	},
	monferno: {
		tier: "PU",
	},
	infernape: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	piplup: {
		tier: "LC",
	},
	prinplup: {
		tier: "NFE",
	},
	empoleon: {
		tier: "UU",
		doublesTier: "DUU",
	},
	starly: {
		tier: "LC",
	},
	staravia: {
		tier: "NFE",
	},
	staraptor: {
		tier: "UUBL",
		doublesTier: "DUU",
	},
	bidoof: {
		tier: "LC",
	},
	bibarel: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	kricketot: {
		tier: "LC",
	},
	kricketune: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	shinx: {
		tier: "LC",
	},
	luxio: {
		tier: "NFE",
	},
	luxray: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	cranidos: {
		tier: "LC",
	},
	rampardos: {
		tier: "PU",
		doublesTier: "DUU",
	},
	shieldon: {
		tier: "LC",
	},
	bastiodon: {
		tier: "NU",
		doublesTier: "DUU",
	},
	burmy: {
		tier: "LC",
	},
	wormadam: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	wormadamsandy: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	wormadamtrash: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	mothim: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	combee: {
		tier: "LC",
	},
	vespiquen: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	pachirisu: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	buizel: {
		tier: "LC",
	},
	floatzel: {
		tier: "NU",
		doublesTier: "DUU",
	},
	cherubi: {
		tier: "LC",
	},
	cherrim: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	cherrimsunshine: {},
	shellos: {
		tier: "LC",
	},
	gastrodon: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	drifloon: {
		tier: "LC",
	},
	drifblim: {
		tier: "NU",
		doublesTier: "DUU",
	},
	buneary: {
		tier: "LC",
	},
	lopunny: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	glameow: {
		tier: "LC",
	},
	purugly: {
		tier: "PU",
		doublesTier: "DUU",
	},
	stunky: {
		tier: "LC",
	},
	skuntank: {
		tier: "NU",
		doublesTier: "DUU",
	},
	bronzor: {
		tier: "PU",
	},
	bronzong: {
		tier: "UU",
		doublesTier: "DOU",
	},
	chatot: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	spiritomb: {
		tier: "RU",
		doublesTier: "DUU",
	},
	gible: {
		tier: "LC",
	},
	gabite: {
		tier: "PU",
	},
	garchomp: {
		tier: "OU",
		doublesTier: "DOU",
	},
	riolu: {
		tier: "PUBL",
		doublesTier: "LC",
	},
	lucario: {
		tier: "OU",
		doublesTier: "DOU",
	},
	hippopotas: {
		tier: "LC",
	},
	hippowdon: {
		tier: "OU",
		doublesTier: "DUU",
	},
	skorupi: {
		tier: "LC",
	},
	drapion: {
		tier: "RU",
		doublesTier: "DUU",
	},
	croagunk: {
		tier: "LC",
	},
	toxicroak: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	carnivine: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	finneon: {
		tier: "LC",
	},
	lumineon: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	snover: {
		tier: "LC",
	},
	abomasnow: {
		tier: "UU",
		doublesTier: "DOU",
	},
	rotom: {
		tier: "RU",
		doublesTier: "DUU",
	},
	rotomheat: {
		tier: "UU",
		doublesTier: "DUU",
	},
	rotomwash: {
		tier: "OU",
		doublesTier: "DOU",
	},
	rotomfrost: {
		tier: "PUBL",
		doublesTier: "DUU",
	},
	rotomfan: {
		tier: "NU",
		doublesTier: "DUU",
	},
	rotommow: {
		tier: "RU",
		doublesTier: "DUU",
	},
	uxie: {
		tier: "RU",
		doublesTier: "DUU",
	},
	mesprit: {
		tier: "RU",
		doublesTier: "DUU",
	},
	azelf: {
		tier: "UU",
		doublesTier: "DUU",
	},
	dialga: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	palkia: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	heatran: {
		tier: "OU",
		doublesTier: "DOU",
	},
	regigigas: {
		tier: "ZUBL",
		doublesTier: "DUU",
	},
	giratina: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	giratinaorigin: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	cresselia: {
		tier: "RUBL",
		doublesTier: "DOU",
	},
	phione: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	manaphy: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	darkrai: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	shaymin: {
		tier: "UU",
		doublesTier: "DUU",
	},
	shayminsky: {
		tier: "Uber",
		doublesTier: "DOU",
	},
	arceus: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	arceusbug: {
	},
	arceusdark: {
	},
	arceusdragon: {
	},
	arceuselectric: {
	},
	arceusfighting: {
	},
	arceusfire: {
	},
	arceusflying: {
	},
	arceusghost: {
	},
	arceusgrass: {
	},
	arceusground: {
	},
	arceusice: {
	},
	arceuspoison: {
	},
	arceuspsychic: {
	},
	arceusrock: {
	},
	arceussteel: {
	},
	arceuswater: {
	},
	victini: {
		tier: "UU",
		doublesTier: "DOU",
	},
	snivy: {
		tier: "LC",
	},
	servine: {
		tier: "NFE",
	},
	serperior: {
		tier: "NU",
		doublesTier: "DUU",
	},
	tepig: {
		tier: "LC",
	},
	pignite: {
		tier: "NFE",
	},
	emboar: {
		tier: "RU",
		doublesTier: "DUU",
	},
	oshawott: {
		tier: "LC",
	},
	dewott: {
		tier: "NFE",
	},
	samurott: {
		tier: "NU",
		doublesTier: "DUU",
	},
	patrat: {
		tier: "LC",
	},
	watchog: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	lillipup: {
		tier: "LC",
	},
	herdier: {
		tier: "NFE",
	},
	stoutland: {
		tier: "PU",
		doublesTier: "DUU",
	},
	purrloin: {
		tier: "LC",
	},
	liepard: {
		tier: "NU",
		doublesTier: "DUU",
	},
	pansage: {
		tier: "LC",
	},
	simisage: {
		tier: "PU",
		doublesTier: "DUU",
	},
	pansear: {
		tier: "LC",
	},
	simisear: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	panpour: {
		tier: "LC",
	},
	simipour: {
		tier: "PUBL",
		doublesTier: "DUU",
	},
	munna: {
		tier: "LC",
	},
	musharna: {
		tier: "NU",
		doublesTier: "DUU",
	},
	pidove: {
		tier: "LC",
	},
	tranquill: {
		tier: "NFE",
	},
	unfezant: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	blitzle: {
		tier: "LC",
	},
	zebstrika: {
		tier: "PU",
		doublesTier: "DUU",
	},
	roggenrola: {
		tier: "LC",
	},
	boldore: {
		tier: "NFE",
	},
	gigalith: {
		tier: "NU",
		doublesTier: "DUU",
	},
	woobat: {
		tier: "LC",
	},
	swoobat: {
		tier: "PU",
		doublesTier: "DUU",
	},
	drilbur: {
		tier: "LC",
	},
	excadrill: {
		tier: "OU",
		doublesTier: "DOU",
	},
	audino: {
		tier: "PU",
		doublesTier: "DUU",
	},
	timburr: {
		tier: "LC",
	},
	gurdurr: {
		tier: "NU",
		doublesTier: "NFE",
	},
	conkeldurr: {
		tier: "OU",
		doublesTier: "DOU",
	},
	tympole: {
		tier: "LC",
	},
	palpitoad: {
		tier: "NFE",
	},
	seismitoad: {
		tier: "NU",
		doublesTier: "DUU",
	},
	throh: {
		tier: "PUBL",
		doublesTier: "DUU",
	},
	sawk: {
		tier: "NU",
		doublesTier: "DUU",
	},
	sewaddle: {
		tier: "LC",
	},
	swadloon: {
		tier: "NFE",
	},
	leavanny: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	venipede: {
		tier: "LC",
	},
	whirlipede: {
		tier: "ZUBL",
		doublesTier: "NFE",
	},
	scolipede: {
		tier: "NUBL",
		doublesTier: "DUU",
	},
	cottonee: {
		tier: "LC",
	},
	whimsicott: {
		tier: "RU",
		doublesTier: "DOU",
	},
	petilil: {
		tier: "LC",
	},
	lilligant: {
		tier: "RU",
		doublesTier: "DUU",
	},
	basculin: {
		tier: "NU",
		doublesTier: "DUU",
	},
	basculinbluestriped: {
		tier: "NU",
		doublesTier: "DUU",
	},
	sandile: {
		tier: "LC",
	},
	krokorok: {
		tier: "PU",
	},
	krookodile: {
		tier: "UU",
		doublesTier: "DUU",
	},
	darumaka: {
		tier: "LC",
	},
	darmanitan: {
		tier: "UU",
		doublesTier: "DUU",
	},
	maractus: {
		tier: "PU",
		doublesTier: "DUU",
	},
	dwebble: {
		tier: "PU",
	},
	crustle: {
		tier: "RU",
		doublesTier: "DUU",
	},
	scraggy: {
		tier: "PU",
	},
	scrafty: {
		tier: "UU",
		doublesTier: "DUU",
	},
	sigilyph: {
		tier: "RU",
		doublesTier: "DUU",
	},
	yamask: {
		tier: "LC",
	},
	cofagrigus: {
		tier: "UU",
		doublesTier: "DUU",
	},
	tirtouga: {
		tier: "LC",
	},
	carracosta: {
		tier: "NU",
		doublesTier: "DUU",
	},
	archen: {
		tier: "LC",
	},
	archeops: {
		tier: "RU",
		doublesTier: "DUU",
	},
	trubbish: {
		tier: "ZUBL",
		doublesTier: "LC",
	},
	garbodor: {
		tier: "NU",
		doublesTier: "DUU",
	},
	zorua: {
		tier: "LC",
	},
	zoroark: {
		tier: "UU",
		doublesTier: "DUU",
	},
	minccino: {
		tier: "LC",
	},
	cinccino: {
		tier: "RU",
		doublesTier: "DUU",
	},
	gothita: {
		tier: "LC",
	},
	gothorita: {
		tier: "PUBL",
		doublesTier: "NFE",
	},
	gothitelle: {
		tier: "UUBL",
		doublesTier: "DUU",
	},
	solosis: {
		tier: "LC",
	},
	duosion: {
		tier: "PU",
	},
	reuniclus: {
		tier: "OU",
		doublesTier: "DOU",
	},
	ducklett: {
		tier: "LC",
	},
	swanna: {
		tier: "PUBL",
		doublesTier: "DUU",
	},
	vanillite: {
		tier: "LC",
	},
	vanillish: {
		tier: "NFE",
	},
	vanilluxe: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	deerling: {
		tier: "LC",
	},
	sawsbuck: {
		tier: "NU",
		doublesTier: "DUU",
	},
	emolga: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	karrablast: {
		tier: "LC",
	},
	escavalier: {
		tier: "RU",
		doublesTier: "DUU",
	},
	foongus: {
		tier: "LC",
	},
	amoonguss: {
		tier: "RU",
		doublesTier: "DOU",
	},
	frillish: {
		tier: "LC",
	},
	jellicent: {
		tier: "OU",
		doublesTier: "DOU",
	},
	alomomola: {
		tier: "NU",
		doublesTier: "DUU",
	},
	joltik: {
		tier: "LC",
	},
	galvantula: {
		tier: "RU",
		doublesTier: "DUU",
	},
	ferroseed: {
		tier: "RU",
		doublesTier: "LC",
	},
	ferrothorn: {
		tier: "OU",
		doublesTier: "DOU",
	},
	klink: {
		tier: "LC",
	},
	klang: {
		tier: "PU",
	},
	klinklang: {
		tier: "RU",
		doublesTier: "DUU",
	},
	tynamo: {
		tier: "LC",
	},
	eelektrik: {
		tier: "NFE",
	},
	eelektross: {
		tier: "NU",
		doublesTier: "DUU",
	},
	elgyem: {
		tier: "LC",
	},
	beheeyem: {
		tier: "PU",
		doublesTier: "DUU",
	},
	litwick: {
		tier: "LC",
	},
	lampent: {
		tier: "NFE",
	},
	chandelure: {
		tier: "UUBL",
		doublesTier: "DOU",
	},
	axew: {
		tier: "LC",
	},
	fraxure: {
		tier: "PU",
	},
	haxorus: {
		tier: "(OU)",
		doublesTier: "DUU",
	},
	cubchoo: {
		tier: "LC",
	},
	beartic: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	cryogonal: {
		tier: "RU",
		doublesTier: "DUU",
	},
	shelmet: {
		tier: "LC",
	},
	accelgor: {
		tier: "RU",
		doublesTier: "DUU",
	},
	stunfisk: {
		tier: "PU",
		doublesTier: "DUU",
	},
	mienfoo: {
		tier: "LC",
	},
	mienshao: {
		tier: "UU",
		doublesTier: "DUU",
	},
	druddigon: {
		tier: "RU",
		doublesTier: "DUU",
	},
	golett: {
		tier: "LC",
	},
	golurk: {
		tier: "NU",
		doublesTier: "DUU",
	},
	pawniard: {
		tier: "LC",
	},
	bisharp: {
		tier: "UU",
		doublesTier: "DUU",
	},
	bouffalant: {
		tier: "RU",
		doublesTier: "DUU",
	},
	rufflet: {
		tier: "LC",
	},
	braviary: {
		tier: "NU",
		doublesTier: "DUU",
	},
	vullaby: {
		tier: "LC",
	},
	mandibuzz: {
		tier: "NU",
		doublesTier: "DUU",
	},
	heatmor: {
		tier: "ZU",
		doublesTier: "DUU",
	},
	durant: {
		tier: "RU",
		doublesTier: "DUU",
	},
	deino: {
		tier: "LC",
	},
	zweilous: {
		tier: "PU",
	},
	hydreigon: {
		tier: "(OU)",
		doublesTier: "DOU",
	},
	larvesta: {
		tier: "LC",
	},
	volcarona: {
		tier: "OU",
		doublesTier: "DOU",
	},
	cobalion: {
		tier: "UU",
		doublesTier: "DUU",
	},
	terrakion: {
		tier: "OU",
		doublesTier: "DOU",
	},
	virizion: {
		tier: "UU",
		doublesTier: "DUU",
	},
	tornadus: {
		tier: "UU",
		doublesTier: "DUU",
	},
	tornadustherian: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	thundurus: {
		tier: "Uber",
		doublesTier: "DOU",
	},
	thundurustherian: {
		tier: "OU",
		doublesTier: "DOU",
	},
	reshiram: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	zekrom: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	landorus: {
		tier: "Uber",
		doublesTier: "DUU",
	},
	landorustherian: {
		tier: "OU",
		doublesTier: "DOU",
	},
	kyurem: {
		tier: "UUBL",
		doublesTier: "DUU",
	},
	kyuremblack: {
		tier: "OU",
		doublesTier: "DOU",
	},
	kyuremwhite: {
		tier: "Uber",
		doublesTier: "DUber",
	},
	keldeo: {
		tier: "OU",
		doublesTier: "DUU",
	},
	keldeoresolute: {
		tier: "OU",
		doublesTier: "DUU",
	},
	meloetta: {
		tier: "UU",
		doublesTier: "DUU",
	},
	meloettapirouette: {
	},
	genesect: {
		tier: "Uber",
		doublesTier: "DOU",
	},
	genesectburn: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	genesectchill: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	genesectdouse: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	genesectshock: {
		tier: "Uber",
		doublesTier: "(DOU)",
	},
	pokestarsmeargle: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarufo: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarufo2: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarbrycenman: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarmt: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarmt2: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestartransport: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestargiant: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestargiant2: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarhumanoid: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarmonster: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarf00: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarf002: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarspirit: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarblackdoor: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarwhitedoor: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarblackbelt: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestargiantpropo2: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
	pokestarufopropu2: {
		isNonstandard: "Unobtainable",
		tier: "Illegal",
	},
};
