// Mechanics desc style (zh-tw): official game terminology, halfwidth numerals (1.5倍, 30%).
// Terminology: 該寶可夢 (this Pokemon), 出場時 (on switch-in), 能力等級 (stat stage),
//   進攻能力 (offensive stat), 瀕死 (fainted/KO), 接觸類招式 (contact move), 連續攻擊招式
//   (multi-hit move), 追加效果 (secondary effect), 異常狀態 (non-volatile status),
//   向下取整 (rounded down), 五捨六入 (rounded half down), 先制招式 (priority move).
// Weather states: 大晴天/下雨/沙暴/冰雹/下雪; harsh: 大日照 (Desolate Land), 大雨
//   (Primordial Sea), 亂流 (Delta Stream).
// Cross-references generated from name fields / pokedex-names.ts. CAP entities keep
//   name null (English fallback); descs are translated with English names inline.

export const AbilitiesText: { [id: IDEntry]: AbilityText } = {
	noability: {
		name: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	adaptability: {
		name: "適應力",
		// Official flavor text: "與自身同屬性的招式 威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	aerilate: {
		name: "飛行皮膚",
		// Official flavor text: "一般屬性的招式 會變為飛行屬性。 威力會少量提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	aftermath: {
		name: "引爆",
		// Official flavor text: "瀕死時， 會對接觸到自己的對手造成傷害。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		damage: "  {POKEMON}受到了傷害！",
	},
	airlock: {
		name: "氣閘",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  天氣的影響消失了！",
	},
	analytic: {
		name: "分析",
		// Official flavor text: "如果在最後使出招式， 招式的威力就會變強。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	angerpoint: {
		name: "憤怒穴位",
		// Official flavor text: "要害被擊中時會大發雷霆。 攻擊力會提高到最大。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		boost: "  {POKEMON}的攻擊被提高到了最大！",
	},
	angershell: {
		name: "憤怒甲殼",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	anticipation: {
		name: "危險預知",
		// Official flavor text: "察覺對手持有的 危險招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		activate: "  {POKEMON}發抖了！",
	},
	arenatrap: {
		name: "沙穴",
		// Official flavor text: "在戰鬥中讓對手無法逃走。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	armortail: {
		name: "尾甲",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		block: "#damp",
	},
	aromaveil: {
		name: "芳香幕",
		// Official flavor text: "可防住向自己和同伴 發出的心靈攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		block: "  {POKEMON}正受到芳香幕的保護！",
	},
	asone: {
		name: "人馬一體",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}兼具２種特性！",
	},
	asoneglastrier: {
		name: "人馬一體（雪暴馬）", // PS-style disambiguator (not part of the official name)
		shortDesc: null, // NEEDS TRANSLATION
	},
	asonespectrier: {
		name: "人馬一體（靈幽馬）", // PS-style disambiguator (not part of the official name)
		shortDesc: null, // NEEDS TRANSLATION
	},
	aurabreak: {
		name: "氣場破壞",
		// Official flavor text: "讓氣場的效果逆轉， 並降低威力。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}壓制了所有氣場！",
	},
	auraguard: {
		name: "氣場破壞",
		shortDesc: null, // NEEDS TRANSLATION
	},
	baddreams: {
		name: "夢魘",
		// Official flavor text: "給予陷入睡眠狀態的對手傷害。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		damage: "  {POKEMON}正被惡夢纏身！",
	},
	ballfetch: {
		name: "撿球",
		shortDesc: null, // NEEDS TRANSLATION
	},
	battery: {
		name: "蓄電池",
		shortDesc: null, // NEEDS TRANSLATION
	},
	battlearmor: {
		name: "戰鬥盔甲",
		shortDesc: null, // NEEDS TRANSLATION
	},
	battlebond: {
		name: "牽絆變身",
		// Official flavor text: "打倒對手時，與訓練家的牽絆會加深， 變化成小智版甲賀忍蛙。 飛水手裡劍的威力會增強。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		activate: "  {POKEMON}渾身充滿了牽絆之力！",
		transform: "{POKEMON}變身成了小智版甲賀忍蛙！",
	},
	beadsofruin: {
		name: "災禍之玉",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  因為{POKEMON}的災禍之玉，周圍的特防減弱了！",
	},
	beastboost: {
		name: "異獸提升",
		// Official flavor text: "打倒對手的時候， 會提高自己最高的那項能力。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	berserk: {
		name: "怒火沖天",
		// Official flavor text: "ＨＰ因對手的攻擊 降到一半時， 特攻會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	bigpecks: {
		name: "健壯胸肌",
		shortDesc: null, // NEEDS TRANSLATION
	},
	blaze: {
		name: "猛火",
		// Official flavor text: "ＨＰ減少的時候， 火屬性的招式威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	bulletproof: {
		name: "防彈",
		shortDesc: null, // NEEDS TRANSLATION
	},
	cheekpouch: {
		name: "頰囊",
		// Official flavor text: "無論是哪種樹果， 吃下去後ＨＰ都會回復。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	chillingneigh: {
		name: "蒼白嘶鳴",
		// Official flavor text: "打倒對手時 會用冰冷的聲音嘶鳴 並提高攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	chlorophyll: {
		name: "葉綠素",
		// Official flavor text: "天氣為晴朗時， 速度會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	clearbody: {
		name: "恆淨之軀",
		shortDesc: null, // NEEDS TRANSLATION
	},
	cloudnine: {
		name: "無關天氣",
		shortDesc: null, // NEEDS TRANSLATION

		start: "#airlock",
	},
	colorchange: {
		name: "變色",
		// Official flavor text: "自己的屬性會變為 擊中自己的對手招式的屬性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	comatose: {
		name: "絕對睡眠",
		// Official flavor text: "總是半夢半醒的狀態， 絕對不會醒來。 可在睡著的狀況下進行攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}處於半夢半醒狀態！",
	},
	commander: {
		name: "發號施令",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}作為發號施令者被{TARGET}吞下去了！",
	},
	competitive: {
		name: "好勝",
		// Official flavor text: "能力被降低時， 特攻會大幅提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	compoundeyes: {
		name: "複眼",
		shortDesc: null, // NEEDS TRANSLATION
	},
	contrary: {
		name: "唱反調",
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	corrosion: {
		name: "腐蝕",
		shortDesc: null, // NEEDS TRANSLATION
	},
	costar: {
		name: "同台共演",
		shortDesc: null, // NEEDS TRANSLATION
	},
	cottondown: {
		name: "棉絮",
		// Official flavor text: "受到攻擊時會撒下棉絮， 降低除自己以外的 所有寶可夢的速度。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	cudchew: {
		name: "反芻",
		shortDesc: null, // NEEDS TRANSLATION
	},
	curiousmedicine: {
		name: "怪藥",
		shortDesc: null, // NEEDS TRANSLATION
	},
	cursedbody: {
		name: "詛咒之軀",
		// Official flavor text: "受到攻擊時， 有時會把對手的招式 變為定身法狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	cutecharm: {
		name: "迷人之軀",
		// Official flavor text: "有時會讓接觸到自己的對手 陷入著迷狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	damp: {
		name: "濕氣",
		// Official flavor text: "透過把周圍都弄濕， 使誰都無法使用自爆等爆炸類的招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		block: "  {SOURCE}無法使用{MOVE}！",
	},
	dancer: {
		name: "舞者",
		// Official flavor text: "當有誰使出跳舞招式時， 自己也能接著使出跳舞招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	darkaura: {
		name: "暗黑氣場",
		// Official flavor text: "全體的惡屬性招式變強。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}釋放著暗黑氣場！",
	},
	dauntlessshield: {
		name: "不屈之盾",
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	dazzling: {
		name: "鮮艷之軀",
		// Official flavor text: "讓對手嚇一跳， 使其無法對我方使出先制招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		block: "#damp",
	},
	defeatist: {
		name: "軟弱",
		// Official flavor text: "ＨＰ降到一半以下時， 會變得軟弱而使得 攻擊和特攻減半。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	defiant: {
		name: "不服輸",
		// Official flavor text: "能力被降低時， 攻擊會大幅提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	deltastream: {
		name: "德爾塔氣流",
		// Official flavor text: "變為令飛行屬性的弱點 消失的天氣。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	desolateland: {
		name: "終結之地",
		// Official flavor text: "變為讓水屬性攻擊 失效的天氣。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	disguise: {
		name: "畫皮",
		// Official flavor text: "用畫皮覆蓋住身體， 可防住１次攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		block: "  畫皮變成了替身！",
		transform: "{POKEMON}的畫皮脫落了！",
	},
	download: {
		name: "下載",
		// Official flavor text: "比較對手的防禦和特防， 根據較低的那項能力 相應地提高自己的攻擊或特攻。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	dragonize: {
		name: "龍皮膚",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	dragonsmaw: {
		name: "龍顎",
		shortDesc: null, // NEEDS TRANSLATION
	},
	drizzle: {
		name: "降雨",
		shortDesc: null, // NEEDS TRANSLATION
	},
	drought: {
		name: "日照",
		shortDesc: null, // NEEDS TRANSLATION
	},
	dryskin: {
		name: "乾燥皮膚",
		// Official flavor text: "下雨天氣時和受到水屬性的招式攻擊時， ＨＰ會回復。晴朗天氣時和受到火屬性的 招式攻擊時，ＨＰ會減少。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},

		damage: "#aftermath",
	},
	earlybird: {
		name: "早起",
		shortDesc: null, // NEEDS TRANSLATION
	},
	eartheater: {
		name: "食土",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	eelevate: {
		name: "鰻鰻高升",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	effectspore: {
		name: "孢子",
		// Official flavor text: "受到攻擊時， 有時會讓接觸到自己的對手 陷入中毒、麻痺或睡眠狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	electricsurge: {
		name: "電氣製造者",
		shortDesc: null, // NEEDS TRANSLATION
	},
	electromorphosis: {
		name: "電力轉換",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}受到{MOVE}而充電了！",
	},
	embodyaspectcornerstone: {
		name: "面影輝映（礎石）", // PS-style disambiguator (not part of the official name)
		shortDesc: null, // NEEDS TRANSLATION

		boost: "  {POKEMON}讓礎之假面綻放光輝，提高了防禦！",
	},
	embodyaspecthearthflame: {
		name: "面影輝映（火灶）", // PS-style disambiguator (not part of the official name)
		shortDesc: null, // NEEDS TRANSLATION

		boost: "  {POKEMON}讓灶之假面綻放光輝，提高了攻擊！",
	},
	embodyaspectteal: {
		name: "面影輝映（碧草）", // PS-style disambiguator (not part of the official name)
		shortDesc: null, // NEEDS TRANSLATION

		boost: "  {POKEMON}讓碧之假面綻放光輝，提高了速度！",
	},
	embodyaspectwellspring: {
		name: "面影輝映（水井）", // PS-style disambiguator (not part of the official name)
		shortDesc: null, // NEEDS TRANSLATION

		boost: "  {POKEMON}讓井之假面綻放光輝，提高了特防！",
	},
	emergencyexit: {
		name: "危險迴避",
		// Official flavor text: "ＨＰ減到一半時， 為了避開危險， 會退回同行隊伍裡面。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	fairyaura: {
		name: "妖精氣場",
		// Official flavor text: "全體的妖精屬性招式變強。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}釋放著妖精氣場！",
	},
	filter: {
		name: "過濾",
		shortDesc: null, // NEEDS TRANSLATION
	},
	firemane: {
		name: "火焰鬃毛",
		shortDesc: null, // NEEDS TRANSLATION
	},
	flamebody: {
		name: "火焰之軀",
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	flareboost: {
		name: "受熱激升",
		// Official flavor text: "陷入灼傷狀態時， 特殊招式的威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	flashfire: {
		name: "引火",
		// Official flavor text: "受到火屬性的招式攻擊時， 吸收火焰，讓自己使出的 火屬性招式變強。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
		},

		start: "  {POKEMON}的火焰威力提高了！",
	},
	flowergift: {
		name: "花之禮",
		// Official flavor text: "天氣為晴朗時， 自己和同伴的攻擊和 特防能力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	flowerveil: {
		name: "花幕",
		// Official flavor text: "我方的草屬性寶可夢 能力不會降低。 也不會陷入異常狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		block: "  {POKEMON}正受到花幕的保護！",
	},
	fluffy: {
		name: "毛茸茸",
		// Official flavor text: "會將對手所給予的接觸類招式的傷害減半， 但火屬性招式的傷害會變為２倍。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	forecast: {
		name: "陰晴不定",
		// Official flavor text: "在天氣的影響下， 會變成水屬性、火屬性 或冰屬性之中的一種。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	forewarn: {
		name: "預知夢",
		// Official flavor text: "出場時，預見１個 對手持有的招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		activate: "  讀取了{TARGET}的{MOVE}！",
		activateNoTarget: null, // NEEDS TRANSLATION
	},
	friendguard: {
		name: "友情防守",
		shortDesc: null, // NEEDS TRANSLATION
	},
	frisk: {
		name: "察覺",
		shortDesc: null, // NEEDS TRANSLATION
		gen5: {
			shortDesc: null, // NEEDS TRANSLATION
		},

		activate: "  {POKEMON}察覺到了{TARGET}的{ITEM}！",
		activateNoTarget: null, // NEEDS TRANSLATION
	},
	fullmetalbody: {
		name: "金屬防護",
		shortDesc: null, // NEEDS TRANSLATION
	},
	furcoat: {
		name: "毛皮大衣",
		shortDesc: null, // NEEDS TRANSLATION
	},
	galewings: {
		name: "疾風之翼",
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	galvanize: {
		name: "電氣皮膚",
		// Official flavor text: "一般屬性的招式 會變為電屬性。 威力會少量提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	gluttony: {
		name: "貪吃鬼",
		// Official flavor text: "原本ＨＰ變得很少時才會吃的樹果， 在ＨＰ還有一半時就會把它吃掉。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	goodasgold: {
		name: "黃金之軀",
		shortDesc: null, // NEEDS TRANSLATION
	},
	gooey: {
		name: "黏滑",
		shortDesc: null, // NEEDS TRANSLATION
	},
	gorillatactics: {
		name: "一猩一意",
		// Official flavor text: "攻擊雖然會提高， 但只能使出 最初選擇的招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	grasspelt: {
		name: "草之毛皮",
		shortDesc: null, // NEEDS TRANSLATION
	},
	grassysurge: {
		name: "青草製造者",
		shortDesc: null, // NEEDS TRANSLATION
	},
	grimneigh: {
		name: "漆黑嘶鳴",
		// Official flavor text: "打倒對手時 會用恐怖的聲音嘶鳴 並提高特攻。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	guarddog: {
		name: "看門犬",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	gulpmissile: {
		name: "一口飛彈",
		// Official flavor text: "衝浪或潛水時會叼來獵物。 當受到傷害時， 會吐出獵物攻擊對手。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	guts: {
		name: "毅力",
		// Official flavor text: "陷入異常狀態時， 會拿出毅力， 攻擊會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	hadronengine: {
		name: "強子引擎",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}布下電氣場地，使未來的機關躍動起來！！",
		activate: "  {POKEMON}透過電氣場地使未來的機關躍動起來！！",
	},
	harvest: {
		name: "收穫",
		// Official flavor text: "可多次採收 已被使用過的樹果。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		addItem: "  {POKEMON}收穫了{ITEM}！",
	},
	healer: {
		name: "治癒之心",
		// Official flavor text: "有時會治癒同伴的異常狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		champions: {
			desc: null, // NEEDS TRANSLATION: not in PokeAPI
			shortDesc: null, // NEEDS TRANSLATION: not in PokeAPI
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	heatproof: {
		name: "耐熱",
		// Official flavor text: "靠著耐熱的體質， 讓火屬性的招式威力減半。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	heavymetal: {
		name: "重金屬",
		// Official flavor text: "自己的重量會變為２倍。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	honeygather: {
		name: "採蜜",
		shortDesc: null, // NEEDS TRANSLATION
	},
	hospitality: {
		name: "款待",
		shortDesc: null, // NEEDS TRANSLATION

		heal: "  {POKEMON}喝光了{SOURCE}泡的茶！",
	},
	hugepower: {
		name: "大力士",
		shortDesc: null, // NEEDS TRANSLATION
	},
	hungerswitch: {
		name: "飽了又餓",
		// Official flavor text: "在每個回合結束時， 會在滿腹花紋和空腹花紋之間 交替改變樣子。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	hustle: {
		name: "活力",
		// Official flavor text: "自己的攻擊雖會變高， 但命中率會降低。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	hydration: {
		name: "濕潤之軀",
		// Official flavor text: "天氣為下雨時， 會治癒異常狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	hypercutter: {
		name: "怪力鉗",
		shortDesc: null, // NEEDS TRANSLATION
	},
	icebody: {
		name: "冰凍之軀",
		// Official flavor text: "天氣為冰雹時， 會漸漸回復ＨＰ。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	iceface: {
		name: "結凍頭",
		// Official flavor text: "頭部的冰會代替自己承受 物理攻擊，但是樣子會改變。 下冰雹時，冰會回復原狀。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	icescales: {
		name: "冰鱗粉",
		shortDesc: null, // NEEDS TRANSLATION
	},
	illuminate: {
		name: "發光",
		// Official flavor text: "透過讓周圍變亮， 變得容易遇見野生的寶可夢。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	illusion: {
		name: "幻覺",
		// Official flavor text: "假扮成同行隊伍中的 最後一隻寶可夢出場， 迷惑對手。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		end: "  {POKEMON}造成的幻覺解除了！",
	},
	immunity: {
		name: "免疫",
		shortDesc: null, // NEEDS TRANSLATION
	},
	imposter: {
		name: "變身者",
		// Official flavor text: "變身為當前面對的寶可夢。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	infiltrator: {
		name: "穿透",
		// Official flavor text: "可穿透對手的屏障 或替身進行攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	innardsout: {
		name: "飛出的內在物",
		// Official flavor text: "被對手打倒的時候， 會給予對手相當於 ＨＰ剩餘量的傷害。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		damage: "#aftermath",
	},
	innerfocus: {
		name: "精神力",
		// Official flavor text: "靠著經過鍛鍊的精神， 不會因對手的攻擊而畏縮。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	insomnia: {
		name: "不眠",
		shortDesc: null, // NEEDS TRANSLATION
	},
	intimidate: {
		name: "威嚇",
		// Official flavor text: "出場時威嚇對手， 使其退縮， 從而降低對手的攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	intrepidsword: {
		name: "不撓之劍",
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	ironbarbs: {
		name: "鐵刺",
		// Official flavor text: "用鐵刺給予接觸到自己的 對手傷害。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		damage: "#roughskin",
	},
	ironfist: {
		name: "鐵拳",
		// Official flavor text: "使用到拳頭的招式 威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	justified: {
		name: "正義之心",
		shortDesc: null, // NEEDS TRANSLATION
	},
	keeneye: {
		name: "銳利目光",
		// Official flavor text: "靠著銳利的目光， 命中率不會被降低。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen5: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	klutz: {
		name: "笨拙",
		// Official flavor text: "無法使用持有的道具。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	leafguard: {
		name: "葉子防守",
		// Official flavor text: "天氣為晴朗時， 不會陷入異常狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	levitate: {
		name: "飄浮",
		// Official flavor text: "從地面浮起， 從而不會受到地面屬性招式的攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	libero: {
		name: "自由者",
		// Official flavor text: "變為與自己使出的招式 相同的屬性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	lightmetal: {
		name: "輕金屬",
		// Official flavor text: "自己的重量會減半。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	lightningrod: {
		name: "避雷針",
		// Official flavor text: "將電屬性的招式吸引到自己身上， 不但不會受到傷害，反而會提高特攻。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		activate: "  {POKEMON}吸引了攻擊！",
	},
	limber: {
		name: "柔軟",
		shortDesc: null, // NEEDS TRANSLATION
	},
	lingeringaroma: {
		name: "甩不掉的氣味",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},

		changeAbility: "  {TARGET}被染上了甩不掉的氣味！",
	},
	liquidooze: {
		name: "污泥漿",
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		damage: "  {POKEMON}吸到了污泥漿！",
	},
	liquidvoice: {
		name: "濕潤之聲",
		// Official flavor text: "所有的聲音招式 都變為水屬性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	longreach: {
		name: "遠隔",
		shortDesc: null, // NEEDS TRANSLATION
	},
	magicbounce: {
		name: "魔法鏡",
		// Official flavor text: "可不受到由對手使出的 變化類招式所影響，並將其反彈。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},

		move: "#magiccoat",
	},
	magicguard: {
		name: "魔法防守",
		// Official flavor text: "不會受到攻擊以外的傷害。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	magician: {
		name: "魔術師",
		// Official flavor text: "奪走被自己招式 擊中的對手的道具。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	magmaarmor: {
		name: "熔岩鎧甲",
		shortDesc: null, // NEEDS TRANSLATION
	},
	magnetpull: {
		name: "磁力",
		// Official flavor text: "用磁力吸住鋼屬性的寶可夢， 使其無法逃走。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	marvelscale: {
		name: "神奇鱗片",
		shortDesc: null, // NEEDS TRANSLATION
	},
	megalauncher: {
		name: "超級發射器",
		// Official flavor text: "波動和波導類招式的 威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	megasol: {
		name: "超級日光",
		shortDesc: null, // NEEDS TRANSLATION
	},
	merciless: {
		name: "不仁不義",
		shortDesc: null, // NEEDS TRANSLATION
	},
	mimicry: {
		name: "擬態",
		// Official flavor text: "寶可夢的屬性會隨著 場地的狀態而改變。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}變回原來的屬性了！",
	},
	mindseye: {
		name: "心眼",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	minus: {
		name: "負電",
		// Official flavor text: "場上的夥伴之中， 如果有正電或負電特性的寶可夢， 自己的特攻會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	mirrorarmor: {
		name: "鏡甲",
		// Official flavor text: "只反彈自己受到的 能力降低效果。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	mistysurge: {
		name: "薄霧製造者",
		shortDesc: null, // NEEDS TRANSLATION
	},
	moldbreaker: {
		name: "破格",
		// Official flavor text: "可不受特性影響， 向對手使出招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		start: "  {POKEMON}打破了常規！",
	},
	moody: {
		name: "心情不定",
		// Official flavor text: "每一回合，能力中的某項 會大幅提高，相對地某項會降低。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	motordrive: {
		name: "電氣引擎",
		// Official flavor text: "受到電屬性的招式攻擊時， 不但不會受到傷害，反而速度會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	moxie: {
		name: "自信過度",
		// Official flavor text: "如果打倒對手， 會充滿自信並提高攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	multiscale: {
		name: "多重鱗片",
		shortDesc: null, // NEEDS TRANSLATION
	},
	multitype: {
		name: "多屬性",
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen6: {
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	mummy: {
		name: "木乃伊",
		// Official flavor text: "被對手接觸到時， 會將對手變成木乃伊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},

		changeAbility: "  {TARGET}的特性變成了木乃伊！",
	},
	myceliummight: {
		name: "菌絲之力",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	naturalcure: {
		name: "自然回復",
		shortDesc: null, // NEEDS TRANSLATION

		activate: null, // NEEDS TRANSLATION
	},
	neuroforce: {
		name: "腦核之力",
		// Official flavor text: "可進一步提升 效果絕佳招式的威力。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	neutralizinggas: {
		name: "化學變化氣體",
		// Official flavor text: "當場上有特性是化學變化氣體的寶可夢時， 所有寶可夢的特性效果 都會消失或無法發動。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},

		start: "  周圍充滿了化學變化氣體！",
		end: "  化學變化氣體的效果消失了！",
	},
	noguard: {
		name: "無防守",
		shortDesc: null, // NEEDS TRANSLATION
	},
	normalize: {
		name: "一般皮膚",
		// Official flavor text: "無論是什麼屬性的招式， 全部都會變為一般屬性。 威力會少量提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	oblivious: {
		name: "遲鈍",
		// Official flavor text: "感覺遲鈍， 不會陷入著迷和被挑釁狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	opportunist: {
		name: "跟風",
		shortDesc: null, // NEEDS TRANSLATION
	},
	orichalcumpulse: {
		name: "緋紅脈動",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}加強日照，使古代的脈動狂暴起來！！",
		activate: "  {POKEMON}受到日照，使古代的脈動狂暴起來！！",
	},
	overcoat: {
		name: "防塵",
		// Official flavor text: "不會受到沙暴或冰雹等的傷害。 不會受到粉末類招式的攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	overgrow: {
		name: "茂盛",
		// Official flavor text: "ＨＰ減少的時候， 草屬性的招式威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	owntempo: {
		name: "我行我素",
		// Official flavor text: "因為我行我素， 不會陷入混亂狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	parentalbond: {
		name: "親子愛",
		// Official flavor text: "親子倆可合計攻擊２次。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	pastelveil: {
		name: "粉彩護幕",
		// Official flavor text: "自己和我方同伴都不會 陷入中毒的異常狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	perishbody: {
		name: "滅亡之軀",
		// Official flavor text: "在受到接觸類招式攻擊時， ３個回合後雙方都會陷入瀕死。 替換寶可夢後效果就會消失。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "  雙方將在３回合後滅亡！",
	},
	pickpocket: {
		name: "順手牽羊",
		// Official flavor text: "盜取接觸到自己的 對手的道具。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	pickup: {
		name: "撿拾",
		// Official flavor text: "有時會撿來對手用過的道具。 冒險過程中也會撿來。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		addItem: "#recycle",
	},
	piercingdrill: {
		name: "貫穿鑽",
		shortDesc: null, // NEEDS TRANSLATION
	},
	pixilate: {
		name: "妖精皮膚",
		// Official flavor text: "一般屬性的招式 會變為妖精屬性。 威力會少量提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	plus: {
		name: "正電",
		// Official flavor text: "場上的夥伴之中， 如果有正電或負電特性的寶可夢， 自己的特攻會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	poisonheal: {
		name: "毒療",
		// Official flavor text: "陷入中毒狀態時， ＨＰ不會減少，反而會漸漸增加。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	poisonpoint: {
		name: "毒刺",
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	poisonpuppeteer: {
		name: "毒傀儡",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	poisontouch: {
		name: "毒手",
		// Official flavor text: "有時僅是接觸 就能讓對手中毒。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	powerconstruct: {
		name: "群聚變形",
		// Official flavor text: "ＨＰ變為一半時， 細胞們會趕來支援， 變為完全體形態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  感受到大量的氣息存在……！",
		transform: "{POKEMON}變成了完全體形態！",
	},
	powerofalchemy: {
		name: "化學之力",
		// Official flavor text: "繼承被打倒的同伴的特性， 變為相同的特性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},

		changeAbility: "#receiver",
	},
	powerspot: {
		name: "能量點",
		// Official flavor text: "只要站在旁邊， 招式的威力就會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	prankster: {
		name: "惡作劇之心",
		// Official flavor text: "可以搶先使出變化類招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	pressure: {
		name: "壓迫感",
		// Official flavor text: "給予對手壓迫感， 大量減少其使用招式的ＰＰ。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		start: "  {POKEMON}釋放著壓迫感！",
	},
	primordialsea: {
		name: "始源之海",
		// Official flavor text: "變為讓火屬性攻擊 失效的天氣。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	prismarmor: {
		name: "稜鏡裝甲",
		shortDesc: null, // NEEDS TRANSLATION
	},
	propellertail: {
		name: "螺旋尾鰭",
		shortDesc: null, // NEEDS TRANSLATION
	},
	protean: {
		name: "變幻自如",
		// Official flavor text: "變為與自己使出的招式 相同的屬性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	protosynthesis: {
		name: "古代活性",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}用大晴天發動了古代活性！",
		activateFromItem: "  {POKEMON}用驅勁能量發動了古代活性！",
		start: "  {POKEMON}的{STAT}升高了！",
		end: "  {POKEMON}的古代活性效果消失了！",
	},
	psychicsurge: {
		name: "精神製造者",
		shortDesc: null, // NEEDS TRANSLATION
	},
	punkrock: {
		name: "龐克搖滾",
		// Official flavor text: "聲音招式的威力會提高。 受到聲音招式的傷害會減半。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	purepower: {
		name: "瑜伽之力",
		shortDesc: null, // NEEDS TRANSLATION
	},
	purifyingsalt: {
		name: "潔淨之鹽",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	quarkdrive: {
		name: "夸克充能",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}透過電氣場地發動了夸克充能！",
		activateFromItem: "  {POKEMON}用驅勁能量發動了夸克充能！",
		start: "  {POKEMON}的{STAT}升高了！",
		end: "  {POKEMON}的夸克充能效果消失了！",
	},
	queenlymajesty: {
		name: "女王的威嚴",
		// Official flavor text: "向對手施加威懾力， 使其無法對我方使出先制招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		block: "#damp",
	},
	quickdraw: {
		name: "速擊",
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  速擊使{POKEMON}行動變快了！",
	},
	quickfeet: {
		name: "飛毛腿",
		// Official flavor text: "陷入異常狀態時， 速度會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	raindish: {
		name: "雨盤",
		// Official flavor text: "天氣為下雨時， 會漸漸回復ＨＰ。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	rattled: {
		name: "膽怯",
		// Official flavor text: "受到惡屬性、幽靈屬性 和蟲屬性的招式攻擊時， 會因膽怯而使得速度提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	receiver: {
		name: "接球手",
		// Official flavor text: "繼承被打倒的同伴的特性， 變為相同的特性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},

		changeAbility: "  繼承了{SOURCE}的{ABILITY}！",
	},
	reckless: {
		name: "捨身",
		// Official flavor text: "會讓自己因反作用力而受傷的招式 威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	refrigerate: {
		name: "冰凍皮膚",
		// Official flavor text: "一般屬性的招式 會變為冰屬性。 威力會少量提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	regenerator: {
		name: "再生力",
		shortDesc: null, // NEEDS TRANSLATION
	},
	ripen: {
		name: "熟成",
		// Official flavor text: "讓樹果成熟， 使效果變為２倍。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	rivalry: {
		name: "鬥爭心",
		// Official flavor text: "面對性別相同的對手， 會燃起鬥爭心，變得更強。 面對性別不同的對手時則會變弱。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	rkssystem: {
		name: "ＡＲ系統",
		shortDesc: null, // NEEDS TRANSLATION
	},
	rockhead: {
		name: "堅硬腦袋",
		// Official flavor text: "即使使出會受反作用力傷害的招式， ＨＰ也不會減少。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	rockypayload: {
		name: "搬岩",
		shortDesc: null, // NEEDS TRANSLATION
	},
	roughskin: {
		name: "粗糙皮膚",
		// Official flavor text: "受到攻擊時， 用粗糙的皮膚弄傷 接觸到自己的對手。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		damage: "  {POKEMON}受到了傷害！",
	},
	runaway: {
		name: "逃跑",
		shortDesc: null, // NEEDS TRANSLATION
	},
	sandforce: {
		name: "沙之力",
		// Official flavor text: "天氣為沙暴時， 岩石屬性、地面屬性 和鋼屬性招式的威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	sandrush: {
		name: "撥沙",
		// Official flavor text: "天氣為沙暴時， 速度會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	sandspit: {
		name: "吐沙",
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	sandstream: {
		name: "揚沙",
		shortDesc: null, // NEEDS TRANSLATION
	},
	sandveil: {
		name: "沙隱",
		// Official flavor text: "在沙暴中 閃避率會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	sapsipper: {
		name: "食草",
		// Official flavor text: "受到草屬性的招式攻擊時， 不但不會受到傷害，反而攻擊會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	schooling: {
		name: "魚群",
		// Official flavor text: "ＨＰ多的時候會聚起來變強。 ＨＰ剩餘量變少時， 群體會分崩離析。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		transform: "{POKEMON}的群體聚集起來了！",
		transformEnd: "{POKEMON}的群體四散而去了！",
	},
	scrappy: {
		name: "膽量",
		// Official flavor text: "一般屬性和格鬥屬性的招式 可擊中幽靈屬性的寶可夢。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	screencleaner: {
		name: "除障",
		shortDesc: null, // NEEDS TRANSLATION
	},
	seedsower: {
		name: "掉出種子",
		shortDesc: null, // NEEDS TRANSLATION
	},
	serenegrace: {
		name: "天恩",
		// Official flavor text: "受到上天保佑， 容易出現招式的追加效果。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	shadowshield: {
		name: "幻影防守",
		shortDesc: null, // NEEDS TRANSLATION
	},
	shadowtag: {
		name: "踩影",
		// Official flavor text: "踩住對手的影子 使其無法逃走或替換。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	sharpness: {
		name: "鋒銳",
		shortDesc: null, // NEEDS TRANSLATION
	},
	shedskin: {
		name: "蛻皮",
		// Official flavor text: "透過蛻去身上的皮， 有時會治癒異常狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	sheerforce: {
		name: "強行",
		// Official flavor text: "招式會失去追加效果， 但可以用更高的威力使出招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	shellarmor: {
		name: "硬殼盔甲",
		shortDesc: null, // NEEDS TRANSLATION
	},
	shielddust: {
		name: "鱗粉",
		// Official flavor text: "被鱗粉守護著， 不會受到招式的追加效果影響。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	shieldsdown: {
		name: "界限盾殼",
		// Official flavor text: "ＨＰ變為一半時， 殼會壞掉，變得更有攻擊性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		transform: "界限盾殼，啟動！",
		transformEnd: "界限盾殼，解除！",
	},
	simple: {
		name: "單純",
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	skilllink: {
		name: "連續攻擊",
		// Official flavor text: "使用連續招式時， 每回都能以最多次數進行攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	slowstart: {
		name: "慢啟動",
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},

		start: "  {POKEMON}無法拿出平時的水準！",
		end: "  {POKEMON}恢復了平時的水準！",
	},
	slushrush: {
		name: "撥雪",
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	sniper: {
		name: "狙擊手",
		shortDesc: null, // NEEDS TRANSLATION
	},
	snowcloak: {
		name: "雪隱",
		// Official flavor text: "天氣為冰雹時， 閃避率會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	snowwarning: {
		name: "降雪",
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	solarpower: {
		name: "太陽之力",
		// Official flavor text: "天氣為晴朗時特攻會提高， 但每回合ＨＰ會減少。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	solidrock: {
		name: "堅硬岩石",
		shortDesc: null, // NEEDS TRANSLATION
	},
	soulheart: {
		name: "魂心",
		shortDesc: null, // NEEDS TRANSLATION
	},
	soundproof: {
		name: "隔音",
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen5: {
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen4: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	speedboost: {
		name: "加速",
		// Official flavor text: "每一回合速度會變快。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	spicyspray: {
		name: "辣椒噴發",
		shortDesc: null, // NEEDS TRANSLATION
	},
	stakeout: {
		name: "監視",
		shortDesc: null, // NEEDS TRANSLATION
	},
	stall: {
		name: "慢出",
		shortDesc: null, // NEEDS TRANSLATION
	},
	stalwart: {
		name: "堅毅",
		shortDesc: null, // NEEDS TRANSLATION
	},
	stamina: {
		name: "持久力",
		shortDesc: null, // NEEDS TRANSLATION
	},
	stancechange: {
		name: "戰鬥切換",
		// Official flavor text: "若使出攻擊招式，會變為刀劍形態， 若使出招式「王者盾牌」， 會變為盾牌形態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},

		transform: "刀劍形態，變形！",
		transformEnd: "盾牌形態，變形！",
	},
	static: {
		name: "靜電",
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	steadfast: {
		name: "不屈之心",
		shortDesc: null, // NEEDS TRANSLATION
	},
	steamengine: {
		name: "蒸汽機",
		// Official flavor text: "受到水屬性或 火屬性招式攻擊時， 速度會極大幅提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	steelworker: {
		name: "鋼能力者",
		shortDesc: null, // NEEDS TRANSLATION
	},
	steelyspirit: {
		name: "鋼之意志",
		// Official flavor text: "我方的鋼屬性 攻擊威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	stench: {
		name: "惡臭",
		// Official flavor text: "發出臭氣， 在攻擊的時候， 有時會使對手畏縮。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	stickyhold: {
		name: "黏著",
		// Official flavor text: "道具會黏在 具有黏性的身體上， 不會被對手奪走。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		block: "  無法奪取{POKEMON}的道具！",
	},
	stormdrain: {
		name: "引水",
		// Official flavor text: "將水屬性的招式引到自己身上， 不但不會受到傷害， 反而會提高特攻。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		activate: "#lightningrod",
	},
	strongjaw: {
		name: "強壯之顎",
		// Official flavor text: "顎部強壯， 會提高啃咬類招式的威力。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	sturdy: {
		name: "結實",
		// Official flavor text: "受到對手的招式攻擊時 不會被一擊打倒。 一擊必殺的招式也沒有效果。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},

		activate: "  {POKEMON}挺住了攻擊！",
	},
	suctioncups: {
		name: "吸盤",
		shortDesc: null, // NEEDS TRANSLATION

		block: "  {POKEMON}用吸盤吸住了！",
	},
	superluck: {
		name: "超幸運",
		shortDesc: null, // NEEDS TRANSLATION
	},
	supersweetsyrup: {
		name: "甘露之蜜",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {POKEMON}的蜜散發出甜甜的氣味！",
	},
	supremeoverlord: {
		name: "大將",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}從被打倒的夥伴那裡得到了力量！",
	},
	surgesurfer: {
		name: "衝浪之尾",
		shortDesc: null, // NEEDS TRANSLATION
	},
	swarm: {
		name: "蟲之預感",
		// Official flavor text: "ＨＰ減少的時候， 蟲屬性的招式威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	sweetveil: {
		name: "甜幕",
		// Official flavor text: "我方的寶可夢 不會陷入睡眠狀態。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		block: "  {POKEMON}因甜幕而不會睡著！",
	},
	swiftswim: {
		name: "悠游自如",
		// Official flavor text: "天氣為下雨時， 速度會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	swordofruin: {
		name: "災禍之劍",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  因為{POKEMON}的災禍之劍，周圍的防禦減弱了！",
	},
	symbiosis: {
		name: "共生",
		// Official flavor text: "同伴使用道具時， 會把自己持有的道具交給同伴。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},

		activate: "  {POKEMON}將{ITEM}交給了{TARGET}！",
	},
	synchronize: {
		name: "同步",
		// Official flavor text: "將自己的中毒、麻痺或 灼傷狀態傳染給對手。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
	},
	tabletsofruin: {
		name: "災禍之簡",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  因為{POKEMON}的災禍之簡，周圍的攻擊減弱了！",
	},
	tangledfeet: {
		name: "蹣跚",
		shortDesc: null, // NEEDS TRANSLATION
	},
	tanglinghair: {
		name: "捲髮",
		shortDesc: null, // NEEDS TRANSLATION
	},
	technician: {
		name: "技術高手",
		// Official flavor text: "可讓威力低的招式 提高威力來進行攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	telepathy: {
		name: "心靈感應",
		shortDesc: null, // NEEDS TRANSLATION

		block: "  {POKEMON}不會受到同伴的攻擊！",
	},
	teraformzero: {
		name: "歸零化境",
		shortDesc: null, // NEEDS TRANSLATION
	},
	terashell: {
		name: "太晶甲殼",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}讓甲殼綻放光輝，扭曲了屬性相剋關係！！",
	},
	terashift: {
		name: "太晶變形",
		shortDesc: null, // NEEDS TRANSLATION

		transform: "{POKEMON}的樣子發生了變化！",
	},
	teravolt: {
		name: "兆級電壓",
		// Official flavor text: "可以不受對手特性的干擾， 向對手使出招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		start: "  {POKEMON}釋放著濺射氣場！",
	},
	thermalexchange: {
		name: "熱交換",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	thickfat: {
		name: "厚脂肪",
		// Official flavor text: "被厚厚的脂肪保護著， 能夠讓火屬性和冰屬性 招式的傷害減半。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	tintedlens: {
		name: "有色眼鏡",
		shortDesc: null, // NEEDS TRANSLATION
	},
	torrent: {
		name: "激流",
		// Official flavor text: "ＨＰ減少的時候， 水屬性的招式威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	toughclaws: {
		name: "硬爪",
		shortDesc: null, // NEEDS TRANSLATION
	},
	toxicboost: {
		name: "中毒激升",
		// Official flavor text: "陷入中毒狀態時， 物理招式的威力會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	toxicchain: {
		name: "毒鎖鏈",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	toxicdebris: {
		name: "毒滿地",
		shortDesc: null, // NEEDS TRANSLATION
	},
	trace: {
		name: "複製",
		// Official flavor text: "出場時，複製對手的特性， 變為與之相同的特性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},
		gen3: {
			desc: null, // NEEDS TRANSLATION
		},

		changeAbility: "  複製了{SOURCE}的{ABILITY}！",
	},
	transistor: {
		name: "電晶體",
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	triage: {
		name: "先行治療",
		shortDesc: null, // NEEDS TRANSLATION
	},
	truant: {
		name: "懶惰",
		shortDesc: null, // NEEDS TRANSLATION
		gen3: {
			desc: null, // NEEDS TRANSLATION
		},

		cant: "{POKEMON}正在偷懶。",
	},
	turboblaze: {
		name: "渦輪火焰",
		// Official flavor text: "可以不受對手特性的干擾， 向對手使出招式。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},
		gen5: {
			desc: null, // NEEDS TRANSLATION
		},
		gen4: {
			desc: null, // NEEDS TRANSLATION
		},

		start: "  {POKEMON}釋放著熾焰氣場！",
	},
	unaware: {
		name: "純樸",
		// Official flavor text: "可無視對手能力的變化， 進行攻擊。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	unburden: {
		name: "輕裝",
		// Official flavor text: "失去所持有的道具時， 速度會提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	unnerve: {
		name: "緊張感",
		// Official flavor text: "讓對手感到緊張， 無法吃樹果。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "  {TEAM}因太緊張而無法食用樹果！",
	},
	unseenfist: {
		name: "無形拳",
		shortDesc: null, // NEEDS TRANSLATION
		champions: {
			shortDesc: null, // NEEDS TRANSLATION: not in PokeAPI
		},
	},
	vesselofruin: {
		name: "災禍之鼎",
		shortDesc: null, // NEEDS TRANSLATION

		start: "  因為{POKEMON}的災禍之鼎，周圍的特攻減弱了！",
	},
	victorystar: {
		name: "勝利之星",
		shortDesc: null, // NEEDS TRANSLATION
	},
	vitalspirit: {
		name: "幹勁",
		shortDesc: null, // NEEDS TRANSLATION
	},
	voltabsorb: {
		name: "蓄電",
		// Official flavor text: "受到電屬性的招式攻擊時， 不會受到傷害，而是會回復。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen3: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	wanderingspirit: {
		name: "遊魂",
		// Official flavor text: "與使用接觸類招式 攻擊自己的寶可夢互換特性。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen8: {
			desc: null, // NEEDS TRANSLATION
		},

		activate: "#skillswap",
	},
	waterabsorb: {
		name: "儲水",
		// Official flavor text: "受到水屬性的招式攻擊時， 不會受到傷害，而是會回復。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	waterbubble: {
		name: "水泡",
		// Official flavor text: "降低自己受到的火屬性 招式的威力。不會灼傷。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	watercompaction: {
		name: "遇水凝固",
		shortDesc: null, // NEEDS TRANSLATION
	},
	waterveil: {
		name: "水幕",
		shortDesc: null, // NEEDS TRANSLATION
	},
	weakarmor: {
		name: "碎裂鎧甲",
		// Official flavor text: "因物理招式受到傷害時， 防禦會降低， 速度會大幅提高。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen6: {
			desc: null, // NEEDS TRANSLATION
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	wellbakedbody: {
		name: "焦香之軀",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	whitesmoke: {
		name: "白色煙霧",
		shortDesc: null, // NEEDS TRANSLATION
	},
	wimpout: {
		name: "躍躍欲逃",
		// Official flavor text: "ＨＰ變為一半時， 會慌慌張張逃走， 退回同行隊伍裡面。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	windpower: {
		name: "風力發電",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		start: "#electromorphosis",
	},
	windrider: {
		name: "乘風",
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	wonderguard: {
		name: "神奇守護",
		shortDesc: null, // NEEDS TRANSLATION
		gen4: {
			shortDesc: null, // NEEDS TRANSLATION
		},
		gen3: {
			shortDesc: null, // NEEDS TRANSLATION
		},
	},
	wonderskin: {
		name: "奇跡皮膚",
		// Official flavor text: "不易受到變化類招式 攻擊的身體。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
	},
	zenmode: {
		name: "達摩模式",
		// Official flavor text: "ＨＰ變為一半以下時， 樣子會改變。"
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION
		gen7: {
			desc: null, // NEEDS TRANSLATION
		},
		gen6: {
			desc: null, // NEEDS TRANSLATION
		},

		transform: "達摩模式，啟動！",
		transformEnd: "達摩模式，解除！",
	},
	zerotohero: {
		name: "全能變身",
		shortDesc: null, // NEEDS TRANSLATION

		activate: "  {POKEMON}在變身之後回來了！",
	},

	// CAP
	mountaineer: {
		name: null, // NEEDS TRANSLATION: not in PokeAPI
		shortDesc: null, // NEEDS TRANSLATION
	},
	rebound: {
		name: null, // NEEDS TRANSLATION: not in PokeAPI
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		move: "#magiccoat",
	},
	persistent: {
		name: null, // NEEDS TRANSLATION: not in PokeAPI
		desc: null, // NEEDS TRANSLATION
		shortDesc: null, // NEEDS TRANSLATION

		activate: null, // NEEDS TRANSLATION
	},
};
